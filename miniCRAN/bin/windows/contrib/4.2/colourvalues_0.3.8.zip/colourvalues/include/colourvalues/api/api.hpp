#ifndef R_COLOURVALUES_API_H
#define R_COLOURVALUES_API_H

#include <Rcpp.h>

#include "colourvalues/api/api_hex.hpp"
#include "colourvalues/api/api_rgb.hpp"
#include "colourvalues/api/api_rgb_interleaved.hpp"

#endif
