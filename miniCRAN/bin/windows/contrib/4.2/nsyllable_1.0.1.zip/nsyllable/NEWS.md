# nsyllable 1.0.1

* Added a `NEWS.md` file to track changes to the package.
* Corrected a test to not rely on literal error message output.

# nsyllable 1.0

* Initial release, with English ("en") only.
