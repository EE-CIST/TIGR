English stoplist is the standard Mallet stoplist.

German, French, Finnish are borrowed from http://www.ranks.nl.
