library("scales")

show_col(excel_pal()(7))
show_col(excel_pal(line = FALSE)(7))
