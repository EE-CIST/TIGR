library("scales")

show_col(calc_pal()(12))
