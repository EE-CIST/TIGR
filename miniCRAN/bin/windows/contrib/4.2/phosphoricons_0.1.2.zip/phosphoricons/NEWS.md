# phosphoricons 0.1.2

* Updated to Phosphoricons 1.4.1



# phosphoricons 0.1.1

* Initial release: use icons by [Phosphoricons](https://phosphoricons.com/) in web pages (shiny, rmarkdown) created with R.
