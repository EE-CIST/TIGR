# webshot2 0.1.0

* Added a `NEWS.md` file to track changes to the package.
