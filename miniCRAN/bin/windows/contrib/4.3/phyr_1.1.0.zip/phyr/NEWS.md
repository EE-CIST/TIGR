# phyr 1.1.0

* Added a `NEWS.md` file to track changes to the package.
* Change function names to follow style of tidyverse (thus a minor version bump)
    + change `pglmm.compare` to `pglmm_compare`
    + change multiple functions of pglmm to follow the `_` style