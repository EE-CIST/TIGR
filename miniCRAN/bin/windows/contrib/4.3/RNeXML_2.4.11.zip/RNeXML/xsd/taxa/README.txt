This directory contains schema fragments to represent operational 
taxonomic units (OTUs, or taxa according to the NEXUS format).