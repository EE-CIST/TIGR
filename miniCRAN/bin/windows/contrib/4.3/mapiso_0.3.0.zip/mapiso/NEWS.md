# mapiso 0.3.0

## Fix
* better min and max values, avoid rounding problems for upper values


# mapiso 0.2.0

## Fix
* reorder data.frame and sf grids along x and y coordinates

## Feat
* add support for SpatVector (input/output)



# mapiso 0.1.2 

## Fix
- avoid invalid geometries by shifting values 
- remove error when CRS do not match between x and mask
