# tanaka 0.3.0

## Minor changes
- replace isoband by mapiso
- use inherits() instead of is() (remove methods from Imports)

# tanaka 0.2.0

## Major changes

- We use terra instead of raster for all things raster
- We use tinytest instead of testthat


# tanaka 0.1.3

## Minor changes

- Changes to accommodate sf >= 0.9 and st_make_valid no longer in lwgeom



# tanaka 0.1.2

## Minor changes

- Changes to accomodate sf >= 0.9 and new representations in PROJ. 




# tanaka 0.1.1

## Minor changes

- addition of `add` argument in tanaka() to add a tanaka layer to and existing
plot.   
- addtition of reference to Tanaka paper. 
- better description of the package (?tanaka)
- add param to correct north arrow
- cleaner raster to matrix transformation in tanaka_contour()
- add reference to GH repo for URL and issues
- use lintr and goodpractice



