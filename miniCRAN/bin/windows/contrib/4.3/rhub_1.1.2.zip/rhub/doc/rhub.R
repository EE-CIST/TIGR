## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(rhub)

## ----platforms-info-----------------------------------------------------------
knitr::kable(platforms(), row.names = FALSE)

