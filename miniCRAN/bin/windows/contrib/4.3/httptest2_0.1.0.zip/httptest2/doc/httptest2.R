## ---- results='hide', echo=FALSE, message=FALSE-----------------------------------------------------------------------
options(width=120)

