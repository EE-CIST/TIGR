# missMDA

You can see the Website dedicated to missMDA (<a href="http://factominer.free.fr/missMDA/index.html">link for English version</a>, and for <a href="http://factominer.free.fr/missMDA/index_fr.html">the French version</a>)


How do you install the latest version of missMDA available on GitHub?

```{r}
if (!require("devtools")) install.packages("devtools")
library(devtools)
install_github("husson/missMDA")
```