if (base::getRversion() >= "2.15.1") {
  utils::globalVariables(c("vcr_c"))
}
