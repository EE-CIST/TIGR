# NA values dealt with in sf_to_GeoJSON and GeoJSON_to_sf

    {
      "type": "character",
      "attributes": {
        "class": {
          "type": "character",
          "attributes": {},
          "value": ["geojson", "json"]
        },
        "crs": {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["input", "wkt"]
            },
            "class": {
              "type": "character",
              "attributes": {},
              "value": ["crs"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": [null]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [null]
            }
          ]
        }
      },
      "value": ["{\"type\":\"FeatureCollection\",\"features\":[{\"type\":\"Feature\",\"properties\":{\"a\":1.0},\"geometry\":{\"type\":\"Point\",\"coordinates\":[0.0,0.0]}},{\"type\":\"Feature\",\"properties\":{\"a\":null},\"geometry\":{\"type\":\"Point\",\"coordinates\":[1.0,1.0]}}]}"]
    }

