#
# Just a shortcut to see what's available inside seqinr
#
lseqinr <- function()
{
  ls("package:seqinr")
}
