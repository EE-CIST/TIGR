library(testthat)
library(rhub)

test_check("rhub")
