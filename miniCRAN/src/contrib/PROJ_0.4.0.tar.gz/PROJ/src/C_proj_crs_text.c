//#include <libproj.h>


#include <R.h>
#include <Rinternals.h>


SEXP C_proj_crs_text(SEXP crs_, SEXP format)
{

  return(R_NilValue);

}
