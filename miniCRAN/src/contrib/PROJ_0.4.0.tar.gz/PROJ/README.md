
<!-- README.md is generated from README.Rmd. Please edit that file -->

# PROJ

PROJ is currently non-operational, all functions return `NULL`. The only
reverse dependency package reproj reverts to use of the proj4 package.

-----

Please note that the PROJ project is released with a [Contributor Code
of
Conduct](https://github.com/hypertidy/PROJ/blob/master/CODE_OF_CONDUCT.md).
By contributing to this project, you agree to abide by its terms.
