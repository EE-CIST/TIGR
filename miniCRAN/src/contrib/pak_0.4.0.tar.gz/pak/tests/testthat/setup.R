
if (!is_private_lib_embedded()) create_dev_lib()
