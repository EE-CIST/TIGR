library("testthat")
library("vdiffr")

test_check("mockpkg")
