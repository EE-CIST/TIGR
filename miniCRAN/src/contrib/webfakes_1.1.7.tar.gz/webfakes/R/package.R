
#' @useDynLib webfakes, .registration = TRUE, .fixes = "c_"
NULL
