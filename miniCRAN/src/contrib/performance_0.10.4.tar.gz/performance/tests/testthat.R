library(testthat)
library(performance)

test_check("performance")
