# check_collinearity, ci = NULL

    Code
      out
    Output
      # Check for Multicollinearity
      
      Low Correlation
      
       Term  VIF Increased SE Tolerance
          N 1.00         1.00      1.00
          P 1.00         1.00      1.00
          K 1.00         1.00      1.00

