/* 
   KrectV3.h

   with or without translation correction

 */

if((*doTrans) == 1) {

#define TRANSLATION
#include "KrectV3.h"

 } else {

#undef TRANSLATION
#include "KrectV3.h"

 }

