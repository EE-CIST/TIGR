wtable <- function(...) {
  stop("This function has been moved to the descriptio package.\n
       Please install it and check the documentation here :\n
       https://nicolas-robette.github.io/descriptio/")
}

pem <- function(...) {
  stop("This function has been moved to the descriptio package.\n
       Please install it and check the documentation here :\n
       https://nicolas-robette.github.io/descriptio/")
}

phi.table <- function(...) {
  stop("This function has been moved to the descriptio package.\n
       Please install it and check the documentation here :\n
       https://nicolas-robette.github.io/descriptio/")
}

assoc.twocont <- function(...) {
  stop("This function has been moved to the descriptio package.\n
       Please install it and check the documentation here :\n
       https://nicolas-robette.github.io/descriptio/")
}

assoc.twocat <- function(...) {
  stop("This function has been moved to the descriptio package.\n
       Please install it and check the documentation here :\n
       https://nicolas-robette.github.io/descriptio/")
}

assoc.catcont <- function(...) {
  stop("This function has been moved to the descriptio package.\n
       Please install it and check the documentation here :\n
       https://nicolas-robette.github.io/descriptio/")
}

assoc.yx <- function(...) {
  stop("This function has been moved to the descriptio package.\n
       Please install it and check the documentation here :\n
       https://nicolas-robette.github.io/descriptio/")
}

catdesc <- function(...) {
  stop("This function has been moved to the descriptio package.\n
       Please install it and check the documentation here :\n
       https://nicolas-robette.github.io/descriptio/")
}

condesc <- function(...) {
  stop("This function has been moved to the descriptio package.\n
       Please install it and check the documentation here :\n
       https://nicolas-robette.github.io/descriptio/")
}

darma <- function(...) {
  stop("This function has been moved to the descriptio package.\n
       Please install it and check the documentation here :\n
       https://nicolas-robette.github.io/descriptio/")
}

ggassoc_phiplot <- function(...) {
  stop("This function has been moved to the descriptio package.\n
       Please install it and check the documentation here :\n
       https://nicolas-robette.github.io/descriptio/")
}

ggassoc_boxplot <- function(...) {
  stop("This function has been moved to the descriptio package.\n
       Please install it and check the documentation here :\n
       https://nicolas-robette.github.io/descriptio/")
}

ggassoc_crosstab <- function(...) {
  stop("This function has been moved to the descriptio package.\n
       Please install it and check the documentation here :\n
       https://nicolas-robette.github.io/descriptio/")
}

ggassoc_scatter <- function(...) {
  stop("This function has been moved to the descriptio package.\n
       Please install it and check the documentation here :\n
       https://nicolas-robette.github.io/descriptio/")
}

translate.logit <- function(...) {
  stop("This function has been moved to the translate.logit package.\n
       Please install it from CRAN.")
}
