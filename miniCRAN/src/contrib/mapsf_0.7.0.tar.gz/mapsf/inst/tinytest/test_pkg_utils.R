expect_silent(mapsf:::load_default_theme())
