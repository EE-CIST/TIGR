library(survey)
options(survey.replicates.mse=TRUE)
example(api)

options(survey.replicates.mse=FALSE)
example(api)
