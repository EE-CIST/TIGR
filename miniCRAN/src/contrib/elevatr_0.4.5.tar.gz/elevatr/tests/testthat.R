library(testthat)
library(elevatr)

test_check("elevatr")
