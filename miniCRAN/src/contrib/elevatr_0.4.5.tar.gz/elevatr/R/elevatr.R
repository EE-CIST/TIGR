#' Access elevation data from the web
#' 
#' This package provides tools to access and download elevation data available
#' from the Mapzen elevation and Mapzen terrain service. 
#'                  
#' @name elevatr
NULL 
