# ensure_igraph() works

    Must provide a graph object (provided wrong object type).

---

    Must provide a graph object (provided wrong object type).

---

    Must provide a graph object (provided `NULL`).

