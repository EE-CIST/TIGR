# as.hclust.igraphHRG() works

    Code
      summary(as.hclust(hrg))
    Output
                  Length Class  Mode     
      merge       66     -none- numeric  
      height      33     -none- numeric  
      order       34     -none- numeric  
      labels      34     -none- numeric  
      method       1     -none- character
      dist.method  1     -none- character

