library(testthat)
library(igraph)

test_check("igraph")
