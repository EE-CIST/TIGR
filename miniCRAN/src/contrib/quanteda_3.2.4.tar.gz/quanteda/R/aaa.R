#' @include quanteda-documentation.R
#' @include meta.R
