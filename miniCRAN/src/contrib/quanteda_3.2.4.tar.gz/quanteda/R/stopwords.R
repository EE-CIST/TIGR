#' @section Stopwords: 
#' 
#' Stopword lists were formerly built into \pkg{quanteda}, but have been moved to the 
#' \pkg{stopwords} package. See [stopwords::stopwords()].
#' @importFrom stopwords stopwords
#' @export 
stopwords::stopwords
