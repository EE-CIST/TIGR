BR told us to replace dfloat with dble
This was the only subroutine affected.
TH
