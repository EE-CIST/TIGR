library(testthat)
library(mda)

test_check("mda")
