# cubelyr 1.0.2

* Fixes for purrr compatibility

# cubelyr 1.0.1

* Fixes for dplyr compatibility

# cubelyr 1.0.0

* Added a `NEWS.md` file to track changes to the package.
