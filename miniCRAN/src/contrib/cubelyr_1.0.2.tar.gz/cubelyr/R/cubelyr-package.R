#' @keywords internal
#' @importFrom glue glue
#' @importFrom purrr map map_int map_lgl map_chr map2_int
#' @importFrom stats setNames
#' @import rlang
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
## usethis namespace: end
NULL
