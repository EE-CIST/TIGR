library(testthat)
library(cubelyr)

test_check("cubelyr")
