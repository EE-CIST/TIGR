# gsl 2.1-8

* Corrections to `configure` and `configure.ac` kindly provided by Kurt Hornik
