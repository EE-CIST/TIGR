#' @title Package description
#' @name mapsf
#' @description
#' Create maps with simple features. mapsf helps to map sf objects and offers
#' features that improve the graphic presentation of maps (scale bar,
#' north arrow, title or legend).
#'
#' @docType package
NULL
