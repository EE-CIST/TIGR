mtq <- mf_get_mtq()


expect_silent(mf_get_ratio(mtq, height = 6))
expect_silent(mf_get_ratio(mtq, width = 7))
expect_silent(mf_get_ratio(mtq))
expect_silent(mf_get_ratio(mtq, width = 3, expandBB = c(0,0,0,.3), theme = "dark"))
expect_message(mf_get_ratio(sf::st_transform(mtq, 4326)))
r <- terra::rast(system.file("ex/elev.tif", package="terra"))
expect_message(mf_get_ratio(r))
expect_equal(mf_get_ratio(mtq), c(7,8.4))
