#ifndef MY_NEW
#define MY_NEW


#endif // MY_NEW
