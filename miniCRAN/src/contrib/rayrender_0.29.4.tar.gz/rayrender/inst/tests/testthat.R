library(testthat)
library(rayrender)

test_check("rayrender")
