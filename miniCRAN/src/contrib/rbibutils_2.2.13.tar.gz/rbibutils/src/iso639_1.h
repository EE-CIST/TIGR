/*
 * iso639_1.h
 */
#ifndef ISO639_1_H
#define ISO639_1_H

char * iso639_1_from_code( const char *code );

#endif
