/*
 * iso639-2 language codes
 */
#ifndef ISO639_2_H
#define ISO639_2_H

char * iso639_2_from_code( char *code );
char * iso639_2_from_language( char *lang );

#endif
