qvcalc.coxph <- function(object, factorname = NULL, coef.indices = NULL,
                         ...) {
    qvcalc.lm(object, factorname, coef.indices, ...)
}
