# recipes_extension_check

    Code
      recipes::recipes_extension_check(pkg = "themis")
    Message <cliMessage>
      v All steps have all method!

