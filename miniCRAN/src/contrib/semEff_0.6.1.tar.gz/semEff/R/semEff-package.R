

#' @keywords internal
#' @aliases semEff-package
"_PACKAGE"
#' @import boot gsl lme4 parallel stats utils
NULL

