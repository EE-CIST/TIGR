check_quarto <- function() {
  Sys.getenv("QUARTO_MESSAGES_FILE") != ""
}
