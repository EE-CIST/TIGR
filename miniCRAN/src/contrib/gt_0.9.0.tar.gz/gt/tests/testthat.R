library(testthat)
library(gt)

test_check("gt")
