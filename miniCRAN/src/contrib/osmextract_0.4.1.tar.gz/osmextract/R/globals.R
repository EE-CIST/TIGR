utils::globalVariables(
  c(
    "geofabrik_zones",
    "test_zones",
    "bbbike_zones",
    "openstreetmap_fr_zones"
  )
)
