# oe_get_keys + values: printing method

    Found 38 unique keys, printed in ascending order of % NA values. The first 10 keys are: 
    surface (91% NAs) = {#asphalt = 12; #paved = 3; #cobblestone = 1; #paving_sto...}
    lanes (92% NAs) = {#2 = 9; #1 = 7}
    bicycle (92% NAs) = {#yes = 10; #designated = 5}
    lit (92% NAs) = {#yes = 15}
    access (93% NAs) = {#permissive = 12; #yes = 2}
    oneway (93% NAs) = {#yes = 13}
    maxspeed (94% NAs) = {#30 mph = 12}
    ref (95% NAs) = {#A660 = 9; #4184 = 1}
    foot (95% NAs) = {#yes = 5; #designated = 4}
    natural (96% NAs) = {#tree_row = 7}
    [Truncated output...]

---

    Found 38 unique keys, printed in ascending order of % NA values. The first 10 keys are: 
    surface (91% NAs) = {#asphalt = 12; #paved = 3; #cobblestone = 1; #paving_sto...}
    lanes (92% NAs) = {#2 = 9; #1 = 7}
    bicycle (92% NAs) = {#yes = 10; #designated = 5}
    lit (92% NAs) = {#yes = 15}
    access (93% NAs) = {#permissive = 12; #yes = 2}
    oneway (93% NAs) = {#yes = 13}
    maxspeed (94% NAs) = {#30 mph = 12}
    ref (95% NAs) = {#A660 = 9; #4184 = 1}
    foot (95% NAs) = {#yes = 5; #designated = 4}
    natural (96% NAs) = {#tree_row = 7}
    [Truncated output...]

