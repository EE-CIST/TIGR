library(testthat)
library(osmextract)

test_check("osmextract")
