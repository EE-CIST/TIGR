library(testthat)
library(nsyllable)

test_check("nsyllable")
