# .First.lib <- function(lib, pkg) library.dynam("pan", pkg, lib)
