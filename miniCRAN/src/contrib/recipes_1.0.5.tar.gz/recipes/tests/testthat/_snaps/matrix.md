# bad args

    Code
      bake(rec, new_data = sacr_te, composition = "matrix")
    Condition
      Error in `convert_matrix()`:
      ! Columns (`beds`, `type`) are not numeric; cannot convert to matrix.

---

    Code
      juice(rec, composition = "matrix")
    Condition
      Error in `convert_matrix()`:
      ! Columns (`beds`, `type`) are not numeric; cannot convert to matrix.

