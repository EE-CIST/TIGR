# recipes_extension_check

    Code
      recipes_extension_check(pkg = "recipes", exclude_steps = "step_testthat_helper",
        exclude_methods = c("required_pkgs"))
    Message
      v All steps have all method!

