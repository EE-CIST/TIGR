# bad args

    Code
      formula(rec10)
    Condition
      Error in `formula()`:
      ! The recipe must be prepped before the formula can be computed.

