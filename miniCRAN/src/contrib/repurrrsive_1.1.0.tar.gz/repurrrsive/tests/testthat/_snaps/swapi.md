# sw_* lists haven't changed

    {
      "type": "list",
      "attributes": {},
      "value": [
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "vehicles", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Luke Skywalker"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["172"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["77"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blond"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["19BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/", "http://swapi.co/api/films/7/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/14/", "http://swapi.co/api/vehicles/30/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/12/", "http://swapi.co/api/starships/22/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-09T13:50:51.644000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:56.891000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/1/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["C-3PO"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["167"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["75"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["gold"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["112BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T15:10:51.357000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.309000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/2/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["R2-D2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["96"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["32"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["white, blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["red"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["33BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/8/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/", "http://swapi.co/api/films/7/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T15:11:50.376000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.311000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/3/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Darth Vader"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["202"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["136"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["white"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["41.9BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/13/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T15:18:20.704000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.313000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/4/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "vehicles", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Leia Organa"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["150"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["49"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["light"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["19BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/", "http://swapi.co/api/films/7/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/30/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T15:20:09.791000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.315000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/5/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Owen Lars"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["178"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["120"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown, grey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["light"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["52BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T15:52:14.024000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.317000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/6/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Beru Whitesun lars"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["165"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["75"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["light"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["47BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T15:53:41.121000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.319000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/7/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["R5-D4"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["97"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["32"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["white, red"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["red"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T15:57:50.959000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.321000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/8/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Biggs Darklighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["183"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["84"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["light"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["24BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/12/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T15:59:50.509000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.323000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/9/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "vehicles", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Obi-Wan Kenobi"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["182"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["77"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["auburn, white"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue-gray"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["57BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/20/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/38/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/48/", "http://swapi.co/api/starships/59/", "http://swapi.co/api/starships/64/", "http://swapi.co/api/starships/65/", "http://swapi.co/api/starships/74/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T16:16:29.192000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.325000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/10/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "vehicles", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Anakin Skywalker"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["188"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["84"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blond"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["41.9BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/44/", "http://swapi.co/api/vehicles/46/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/59/", "http://swapi.co/api/starships/65/", "http://swapi.co/api/starships/39/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T16:20:44.310000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.327000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/11/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Wilhuff Tarkin"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["auburn, grey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["64BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/21/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T16:26:56.138000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.330000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/12/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "vehicles", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Chewbacca"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["228"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["112"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["200BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/14/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/", "http://swapi.co/api/films/7/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/19/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/10/", "http://swapi.co/api/starships/22/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T16:42:45.066000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.332000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/13/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Han Solo"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["80"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["29BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/22/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/", "http://swapi.co/api/films/7/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/10/", "http://swapi.co/api/starships/22/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T16:49:14.582000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.334000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/14/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Greedo"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["173"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["74"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["green"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["44BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/23/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T17:03:30.334000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.336000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/15/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Jabba Desilijic Tiure"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["175"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1,358"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["green-tan, brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["orange"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["600BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["hermaphrodite"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/24/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T17:11:31.638000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.338000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/16/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "vehicles", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Wedge Antilles"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["170"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["77"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["hazel"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["21BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/22/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/14/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/12/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-12T11:08:06.469000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.341000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/18/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Jek Tono Porkins"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["110"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/26/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/12/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-12T11:16:56.569000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.343000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/19/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Yoda"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["66"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["17"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["white"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["green"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["896BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/28/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:26:01.042000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.345000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/20/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Palpatine"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["170"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["75"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["pale"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["82BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/8/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:48:05.971000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.347000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/21/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Boba Fett"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["183"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["78.2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["31.5BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/10/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/21/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:49:32.457000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.349000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/22/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["IG-88"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["140"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["metal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["red"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["15BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/28/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:51:10.076000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.351000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/23/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Bossk"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["190"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["113"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["green"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["red"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["53BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/29/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/7/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:53:49.297000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.355000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/24/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Lando Calrissian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["177"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["79"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["dark"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["31BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/30/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/10/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:56:32.683000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.357000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/25/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Lobot"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["175"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["79"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["light"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["37BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T13:01:57.178000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.359000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/26/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Ackbar"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["83"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown mottle"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["orange"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["41BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/31/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/", "http://swapi.co/api/films/7/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/8/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T11:07:50.584000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.362000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/27/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Mon Mothma"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["150"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["auburn"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["48BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/32/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T11:12:38.895000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.364000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/28/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Arvel Crynyd"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/28/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/28/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T11:16:33.020000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.367000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/29/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Wicket Systri Warrick"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["88"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["8BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/7/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/9/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T11:21:58.954000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.369000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/30/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Nien Nunb"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["160"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["68"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/33/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/10/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/10/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T11:26:18.541000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.371000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/31/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "vehicles", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Qui-Gon Jinn"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["193"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["89"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["92BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/28/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/38/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T16:54:53.618000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.375000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/32/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Nute Gunray"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["191"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["90"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mottled green"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["red"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/18/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/11/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:05:57.357000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.377000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/33/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Finis Valorum"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["170"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blond"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["91BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/9/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:21:45.915000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.379000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/34/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Jar Jar Binks"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["196"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["66"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["orange"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["orange"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["52BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/8/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/12/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:29:32.489000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.383000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/36/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Roos Tarpals"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["224"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["82"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["orange"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/8/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/12/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:32:56.741000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.385000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/37/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Rugor Nass"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["206"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["green"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["orange"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/8/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/12/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:33:38.909000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.388000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/38/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Ric Olié"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["183"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/8/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/40/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:45:01.522000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.392000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/39/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Watto"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["137"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue, grey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/34/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/13/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:48:54.647000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.395000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/40/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Sebulba"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["112"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["40"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey, red"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["orange"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/35/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/14/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:53:02.586000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.397000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/41/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Quarsh Panaka"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["183"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["dark"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["62BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/8/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:55:43.348000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.399000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/42/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Shmi Skywalker"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["163"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["72BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:57:41.191000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.401000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/43/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "vehicles", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Darth Maul"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["175"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["80"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["red"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["54BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/36/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/22/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/42/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/41/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T18:00:41.929000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.403000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/44/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Bib Fortuna"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["pale"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["pink"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/37/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/15/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T09:47:02.512000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.407000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/45/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Ayla Secura"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["178"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["55"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["hazel"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["48BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/37/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/15/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T09:48:01.172000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.409000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/46/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Dud Bolt"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["94"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["45"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue, grey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/39/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/17/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T09:57:31.858000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.414000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/48/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Gasgano"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["122"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["white, blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/40/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/18/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:02:12.223000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.416000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/49/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Ben Quadinaros"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["163"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["65"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey, green, yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["orange"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/41/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/19/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:08:33.777000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.417000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/50/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Mace Windu"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["188"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["84"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["dark"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["72BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/42/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:12:30.846000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.420000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/51/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Ki-Adi-Mundi"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["198"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["82"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["white"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["pale"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["92BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/43/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/20/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:15:32.293000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.422000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/52/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Kit Fisto"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["196"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["87"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["green"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/44/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/21/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:18:57.202000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.424000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/53/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Eeth Koth"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["171"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/45/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/22/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:26:47.902000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.427000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/54/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Adi Gallia"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["184"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["50"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["dark"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/9/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/23/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:29:11.661000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.432000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/55/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Saesee Tiin"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["188"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["pale"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["orange"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/47/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/24/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:32:11.669000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.434000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/56/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Yarael Poof"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["264"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["white"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/48/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/25/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:34:48.725000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.437000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/57/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Plo Koon"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["188"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["80"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["orange"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["22BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/49/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/26/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/48/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:49:19.859000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.439000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/58/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Mas Amedda"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["196"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/50/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/27/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:53:26.457000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.442000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/59/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Gregar Typho"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["185"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["85"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["dark"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/8/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/39/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T11:10:10.381000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.445000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/60/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Cordé"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["157"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["light"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/8/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T11:11:39.630000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.449000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/61/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Cliegg Lars"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["183"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["82BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T15:59:03.958000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.451000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/62/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Poggle the Lesser"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["183"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["80"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["green"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/11/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/28/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T16:40:43.977000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.453000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/63/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Luminara Unduli"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["170"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["56.2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["58BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/51/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/29/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T16:45:53.668000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.455000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/64/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Barriss Offee"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["166"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["50"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["40BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/51/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/29/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T16:46:40.440000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.457000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/65/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Dormé"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["165"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["light"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/8/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T16:49:14.640000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.460000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/66/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "vehicles", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Dooku"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["193"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["80"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["white"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["102BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/52/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/55/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T16:52:14.726000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.462000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/67/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Bail Prestor Organa"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["191"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["tan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["67BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T16:53:08.575000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.463000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/68/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Jango Fett"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["183"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["79"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["tan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["66BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/53/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T16:54:41.620000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.465000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/69/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "vehicles", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Zam Wesell"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["168"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["55"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blonde"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair, green, yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/54/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/30/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/45/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T16:57:44.471000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.468000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/70/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Dexter Jettster"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["198"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["102"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/55/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/31/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:28:27.248000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.470000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/71/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Lama Su"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["229"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["88"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/10/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/32/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:30:50.416000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.473000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/72/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Taun We"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["213"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/10/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/32/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:31:21.195000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.474000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/73/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Jocasta Nu"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["167"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["white"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/9/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:32:51.996000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.476000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/74/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Ratts Tyerell"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["79"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["15"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey, blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/38/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/16/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T09:53:15.086000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2016-06-30T12:52:19.604868Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/47/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["R4-P17"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["96"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["silver, red"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["red, blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/28/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:43:36.409000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.478000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/75/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Wat Tambor"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["193"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["48"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["green, grey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/56/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/33/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:53:52.607000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.481000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/76/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["San Hill"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["191"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["gold"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/57/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/34/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:58:17.049000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.484000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/77/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Shaak Ti"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["178"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["57"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["red, blue, white"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/58/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/35/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T18:44:01.103000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.486000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/78/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "vehicles", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Grievous"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["216"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["159"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown, white"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["green, yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/59/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/36/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/60/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/74/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T19:43:53.348000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.488000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/79/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Tarfful"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["234"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["136"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/14/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T19:46:34.209000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.491000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/80/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Raymus Antilles"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["188"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["79"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["light"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T19:49:35.583000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.493000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/81/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Sly Moore"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["178"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["48"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["pale"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["white"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/60/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:18:37.619000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.496000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/82/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Tion Medon"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["206"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["80"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/12/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/37/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:35:04.260000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:17:50.498000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/83/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Finn"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["dark"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["dark"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/28/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/7/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-17T06:52:40.793621Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-17T06:52:40.793674Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/84/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Rey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["light"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["hazel"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/28/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/7/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-17T06:54:01.495077Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-17T06:54:01.495128Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/85/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Poe Dameron"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["light"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/28/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/7/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/77/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-17T06:55:21.622786Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-17T06:55:21.622835Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/86/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["BB8"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/28/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/7/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-17T06:57:38.061346Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-17T06:57:38.061453Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/87/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Captain Phasma"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/28/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/7/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-10-13T10:35:39.229823Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-10-13T10:35:39.229894Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/88/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "height", "mass", "hair_color", "skin_color", "eye_color", "birth_year", "gender", "homeworld", "films", "species", "starships", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Padmé Amidala"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["165"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["45"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["light"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["46BBY"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/8/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/49/", "http://swapi.co/api/starships/64/", "http://swapi.co/api/starships/39/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:28:26.926000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2016-04-20T17:06:31.502555Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/35/"]
            }
          ]
        }
      ]
    }

---

    {
      "type": "list",
      "attributes": {},
      "value": [
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["title", "episode_id", "opening_crawl", "director", "producer", "release_date", "characters", "planets", "starships", "vehicles", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["A New Hope"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [4]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["It is a period of civil war.\r\nRebel spaceships, striking\r\nfrom a hidden base, have won\r\ntheir first victory against\r\nthe evil Galactic Empire.\r\n\r\nDuring the battle, Rebel\r\nspies managed to steal secret\r\nplans to the Empire's\r\nultimate weapon, the DEATH\r\nSTAR, an armored space\r\nstation with enough power\r\nto destroy an entire planet.\r\n\r\nPursued by the Empire's\r\nsinister agents, Princess\r\nLeia races home aboard her\r\nstarship, custodian of the\r\nstolen plans that can save her\r\npeople and restore\r\nfreedom to the galaxy...."]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["George Lucas"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Gary Kurtz, Rick McCallum"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1977-05-25"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/1/", "http://swapi.co/api/people/2/", "http://swapi.co/api/people/3/", "http://swapi.co/api/people/4/", "http://swapi.co/api/people/5/", "http://swapi.co/api/people/6/", "http://swapi.co/api/people/7/", "http://swapi.co/api/people/8/", "http://swapi.co/api/people/9/", "http://swapi.co/api/people/10/", "http://swapi.co/api/people/12/", "http://swapi.co/api/people/13/", "http://swapi.co/api/people/14/", "http://swapi.co/api/people/15/", "http://swapi.co/api/people/16/", "http://swapi.co/api/people/18/", "http://swapi.co/api/people/19/", "http://swapi.co/api/people/81/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/2/", "http://swapi.co/api/planets/3/", "http://swapi.co/api/planets/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/2/", "http://swapi.co/api/starships/3/", "http://swapi.co/api/starships/5/", "http://swapi.co/api/starships/9/", "http://swapi.co/api/starships/10/", "http://swapi.co/api/starships/11/", "http://swapi.co/api/starships/12/", "http://swapi.co/api/starships/13/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/4/", "http://swapi.co/api/vehicles/6/", "http://swapi.co/api/vehicles/7/", "http://swapi.co/api/vehicles/8/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/5/", "http://swapi.co/api/species/3/", "http://swapi.co/api/species/2/", "http://swapi.co/api/species/1/", "http://swapi.co/api/species/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T14:23:31.880000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-11T09:46:52.774897Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/1/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["title", "episode_id", "opening_crawl", "director", "producer", "release_date", "characters", "planets", "starships", "vehicles", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Attack of the Clones"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [2]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["There is unrest in the Galactic\r\nSenate. Several thousand solar\r\nsystems have declared their\r\nintentions to leave the Republic.\r\n\r\nThis separatist movement,\r\nunder the leadership of the\r\nmysterious Count Dooku, has\r\nmade it difficult for the limited\r\nnumber of Jedi Knights to maintain \r\npeace and order in the galaxy.\r\n\r\nSenator Amidala, the former\r\nQueen of Naboo, is returning\r\nto the Galactic Senate to vote\r\non the critical issue of creating\r\nan ARMY OF THE REPUBLIC\r\nto assist the overwhelmed\r\nJedi...."]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["George Lucas"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Rick McCallum"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2002-05-16"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/2/", "http://swapi.co/api/people/3/", "http://swapi.co/api/people/6/", "http://swapi.co/api/people/7/", "http://swapi.co/api/people/10/", "http://swapi.co/api/people/11/", "http://swapi.co/api/people/20/", "http://swapi.co/api/people/21/", "http://swapi.co/api/people/22/", "http://swapi.co/api/people/33/", "http://swapi.co/api/people/36/", "http://swapi.co/api/people/40/", "http://swapi.co/api/people/43/", "http://swapi.co/api/people/46/", "http://swapi.co/api/people/51/", "http://swapi.co/api/people/52/", "http://swapi.co/api/people/53/", "http://swapi.co/api/people/58/", "http://swapi.co/api/people/59/", "http://swapi.co/api/people/60/", "http://swapi.co/api/people/61/", "http://swapi.co/api/people/62/", "http://swapi.co/api/people/63/", "http://swapi.co/api/people/64/", "http://swapi.co/api/people/65/", "http://swapi.co/api/people/66/", "http://swapi.co/api/people/67/", "http://swapi.co/api/people/68/", "http://swapi.co/api/people/69/", "http://swapi.co/api/people/70/", "http://swapi.co/api/people/71/", "http://swapi.co/api/people/72/", "http://swapi.co/api/people/73/", "http://swapi.co/api/people/74/", "http://swapi.co/api/people/75/", "http://swapi.co/api/people/76/", "http://swapi.co/api/people/77/", "http://swapi.co/api/people/78/", "http://swapi.co/api/people/82/", "http://swapi.co/api/people/35/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/8/", "http://swapi.co/api/planets/9/", "http://swapi.co/api/planets/10/", "http://swapi.co/api/planets/11/", "http://swapi.co/api/planets/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/21/", "http://swapi.co/api/starships/39/", "http://swapi.co/api/starships/43/", "http://swapi.co/api/starships/47/", "http://swapi.co/api/starships/48/", "http://swapi.co/api/starships/49/", "http://swapi.co/api/starships/32/", "http://swapi.co/api/starships/52/", "http://swapi.co/api/starships/58/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/4/", "http://swapi.co/api/vehicles/44/", "http://swapi.co/api/vehicles/45/", "http://swapi.co/api/vehicles/46/", "http://swapi.co/api/vehicles/50/", "http://swapi.co/api/vehicles/51/", "http://swapi.co/api/vehicles/53/", "http://swapi.co/api/vehicles/54/", "http://swapi.co/api/vehicles/55/", "http://swapi.co/api/vehicles/56/", "http://swapi.co/api/vehicles/57/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/32/", "http://swapi.co/api/species/33/", "http://swapi.co/api/species/2/", "http://swapi.co/api/species/35/", "http://swapi.co/api/species/6/", "http://swapi.co/api/species/1/", "http://swapi.co/api/species/12/", "http://swapi.co/api/species/34/", "http://swapi.co/api/species/13/", "http://swapi.co/api/species/15/", "http://swapi.co/api/species/28/", "http://swapi.co/api/species/29/", "http://swapi.co/api/species/30/", "http://swapi.co/api/species/31/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:57:57.886000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-11T09:45:01.623982Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["title", "episode_id", "opening_crawl", "director", "producer", "release_date", "characters", "planets", "starships", "vehicles", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["The Phantom Menace"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [1]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Turmoil has engulfed the\r\nGalactic Republic. The taxation\r\nof trade routes to outlying star\r\nsystems is in dispute.\r\n\r\nHoping to resolve the matter\r\nwith a blockade of deadly\r\nbattleships, the greedy Trade\r\nFederation has stopped all\r\nshipping to the small planet\r\nof Naboo.\r\n\r\nWhile the Congress of the\r\nRepublic endlessly debates\r\nthis alarming chain of events,\r\nthe Supreme Chancellor has\r\nsecretly dispatched two Jedi\r\nKnights, the guardians of\r\npeace and justice in the\r\ngalaxy, to settle the conflict...."]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["George Lucas"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Rick McCallum"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1999-05-19"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/2/", "http://swapi.co/api/people/3/", "http://swapi.co/api/people/10/", "http://swapi.co/api/people/11/", "http://swapi.co/api/people/16/", "http://swapi.co/api/people/20/", "http://swapi.co/api/people/21/", "http://swapi.co/api/people/32/", "http://swapi.co/api/people/33/", "http://swapi.co/api/people/34/", "http://swapi.co/api/people/36/", "http://swapi.co/api/people/37/", "http://swapi.co/api/people/38/", "http://swapi.co/api/people/39/", "http://swapi.co/api/people/40/", "http://swapi.co/api/people/41/", "http://swapi.co/api/people/42/", "http://swapi.co/api/people/43/", "http://swapi.co/api/people/44/", "http://swapi.co/api/people/46/", "http://swapi.co/api/people/48/", "http://swapi.co/api/people/49/", "http://swapi.co/api/people/50/", "http://swapi.co/api/people/51/", "http://swapi.co/api/people/52/", "http://swapi.co/api/people/53/", "http://swapi.co/api/people/54/", "http://swapi.co/api/people/55/", "http://swapi.co/api/people/56/", "http://swapi.co/api/people/57/", "http://swapi.co/api/people/58/", "http://swapi.co/api/people/59/", "http://swapi.co/api/people/47/", "http://swapi.co/api/people/35/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/8/", "http://swapi.co/api/planets/9/", "http://swapi.co/api/planets/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/40/", "http://swapi.co/api/starships/41/", "http://swapi.co/api/starships/31/", "http://swapi.co/api/starships/32/", "http://swapi.co/api/starships/39/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/33/", "http://swapi.co/api/vehicles/34/", "http://swapi.co/api/vehicles/35/", "http://swapi.co/api/vehicles/36/", "http://swapi.co/api/vehicles/37/", "http://swapi.co/api/vehicles/38/", "http://swapi.co/api/vehicles/42/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/", "http://swapi.co/api/species/2/", "http://swapi.co/api/species/6/", "http://swapi.co/api/species/11/", "http://swapi.co/api/species/12/", "http://swapi.co/api/species/13/", "http://swapi.co/api/species/14/", "http://swapi.co/api/species/15/", "http://swapi.co/api/species/16/", "http://swapi.co/api/species/17/", "http://swapi.co/api/species/18/", "http://swapi.co/api/species/19/", "http://swapi.co/api/species/20/", "http://swapi.co/api/species/21/", "http://swapi.co/api/species/22/", "http://swapi.co/api/species/23/", "http://swapi.co/api/species/24/", "http://swapi.co/api/species/25/", "http://swapi.co/api/species/26/", "http://swapi.co/api/species/27/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T16:52:55.740000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-11T09:45:18.689301Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["title", "episode_id", "opening_crawl", "director", "producer", "release_date", "characters", "planets", "starships", "vehicles", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Revenge of the Sith"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [3]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["War! The Republic is crumbling\r\nunder attacks by the ruthless\r\nSith Lord, Count Dooku.\r\nThere are heroes on both sides.\r\nEvil is everywhere.\r\n\r\nIn a stunning move, the\r\nfiendish droid leader, General\r\nGrievous, has swept into the\r\nRepublic capital and kidnapped\r\nChancellor Palpatine, leader of\r\nthe Galactic Senate.\r\n\r\nAs the Separatist Droid Army\r\nattempts to flee the besieged\r\ncapital with their valuable\r\nhostage, two Jedi Knights lead a\r\ndesperate mission to rescue the\r\ncaptive Chancellor...."]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["George Lucas"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Rick McCallum"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2005-05-19"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/1/", "http://swapi.co/api/people/2/", "http://swapi.co/api/people/3/", "http://swapi.co/api/people/4/", "http://swapi.co/api/people/5/", "http://swapi.co/api/people/6/", "http://swapi.co/api/people/7/", "http://swapi.co/api/people/10/", "http://swapi.co/api/people/11/", "http://swapi.co/api/people/12/", "http://swapi.co/api/people/13/", "http://swapi.co/api/people/20/", "http://swapi.co/api/people/21/", "http://swapi.co/api/people/33/", "http://swapi.co/api/people/46/", "http://swapi.co/api/people/51/", "http://swapi.co/api/people/52/", "http://swapi.co/api/people/53/", "http://swapi.co/api/people/54/", "http://swapi.co/api/people/55/", "http://swapi.co/api/people/56/", "http://swapi.co/api/people/58/", "http://swapi.co/api/people/63/", "http://swapi.co/api/people/64/", "http://swapi.co/api/people/67/", "http://swapi.co/api/people/68/", "http://swapi.co/api/people/75/", "http://swapi.co/api/people/78/", "http://swapi.co/api/people/79/", "http://swapi.co/api/people/80/", "http://swapi.co/api/people/81/", "http://swapi.co/api/people/82/", "http://swapi.co/api/people/83/", "http://swapi.co/api/people/35/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/2/", "http://swapi.co/api/planets/5/", "http://swapi.co/api/planets/8/", "http://swapi.co/api/planets/9/", "http://swapi.co/api/planets/12/", "http://swapi.co/api/planets/13/", "http://swapi.co/api/planets/14/", "http://swapi.co/api/planets/15/", "http://swapi.co/api/planets/16/", "http://swapi.co/api/planets/17/", "http://swapi.co/api/planets/18/", "http://swapi.co/api/planets/19/", "http://swapi.co/api/planets/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/48/", "http://swapi.co/api/starships/59/", "http://swapi.co/api/starships/61/", "http://swapi.co/api/starships/32/", "http://swapi.co/api/starships/63/", "http://swapi.co/api/starships/64/", "http://swapi.co/api/starships/65/", "http://swapi.co/api/starships/66/", "http://swapi.co/api/starships/68/", "http://swapi.co/api/starships/74/", "http://swapi.co/api/starships/75/", "http://swapi.co/api/starships/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/33/", "http://swapi.co/api/vehicles/50/", "http://swapi.co/api/vehicles/60/", "http://swapi.co/api/vehicles/62/", "http://swapi.co/api/vehicles/67/", "http://swapi.co/api/vehicles/69/", "http://swapi.co/api/vehicles/70/", "http://swapi.co/api/vehicles/71/", "http://swapi.co/api/vehicles/72/", "http://swapi.co/api/vehicles/73/", "http://swapi.co/api/vehicles/76/", "http://swapi.co/api/vehicles/53/", "http://swapi.co/api/vehicles/56/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/19/", "http://swapi.co/api/species/33/", "http://swapi.co/api/species/2/", "http://swapi.co/api/species/3/", "http://swapi.co/api/species/36/", "http://swapi.co/api/species/37/", "http://swapi.co/api/species/6/", "http://swapi.co/api/species/1/", "http://swapi.co/api/species/34/", "http://swapi.co/api/species/15/", "http://swapi.co/api/species/35/", "http://swapi.co/api/species/20/", "http://swapi.co/api/species/23/", "http://swapi.co/api/species/24/", "http://swapi.co/api/species/25/", "http://swapi.co/api/species/26/", "http://swapi.co/api/species/27/", "http://swapi.co/api/species/28/", "http://swapi.co/api/species/29/", "http://swapi.co/api/species/30/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T18:49:38.403000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-11T09:45:44.862122Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["title", "episode_id", "opening_crawl", "director", "producer", "release_date", "characters", "planets", "starships", "vehicles", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Return of the Jedi"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [6]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Luke Skywalker has returned to\r\nhis home planet of Tatooine in\r\nan attempt to rescue his\r\nfriend Han Solo from the\r\nclutches of the vile gangster\r\nJabba the Hutt.\r\n\r\nLittle does Luke know that the\r\nGALACTIC EMPIRE has secretly\r\nbegun construction on a new\r\narmored space station even\r\nmore powerful than the first\r\ndreaded Death Star.\r\n\r\nWhen completed, this ultimate\r\nweapon will spell certain doom\r\nfor the small band of rebels\r\nstruggling to restore freedom\r\nto the galaxy..."]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Richard Marquand"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Howard G. Kazanjian, George Lucas, Rick McCallum"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1983-05-25"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/1/", "http://swapi.co/api/people/2/", "http://swapi.co/api/people/3/", "http://swapi.co/api/people/4/", "http://swapi.co/api/people/5/", "http://swapi.co/api/people/10/", "http://swapi.co/api/people/13/", "http://swapi.co/api/people/14/", "http://swapi.co/api/people/16/", "http://swapi.co/api/people/18/", "http://swapi.co/api/people/20/", "http://swapi.co/api/people/21/", "http://swapi.co/api/people/22/", "http://swapi.co/api/people/25/", "http://swapi.co/api/people/27/", "http://swapi.co/api/people/28/", "http://swapi.co/api/people/29/", "http://swapi.co/api/people/30/", "http://swapi.co/api/people/31/", "http://swapi.co/api/people/45/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/5/", "http://swapi.co/api/planets/7/", "http://swapi.co/api/planets/8/", "http://swapi.co/api/planets/9/", "http://swapi.co/api/planets/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/10/", "http://swapi.co/api/starships/11/", "http://swapi.co/api/starships/12/", "http://swapi.co/api/starships/15/", "http://swapi.co/api/starships/22/", "http://swapi.co/api/starships/23/", "http://swapi.co/api/starships/27/", "http://swapi.co/api/starships/28/", "http://swapi.co/api/starships/29/", "http://swapi.co/api/starships/3/", "http://swapi.co/api/starships/17/", "http://swapi.co/api/starships/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/8/", "http://swapi.co/api/vehicles/16/", "http://swapi.co/api/vehicles/18/", "http://swapi.co/api/vehicles/19/", "http://swapi.co/api/vehicles/24/", "http://swapi.co/api/vehicles/25/", "http://swapi.co/api/vehicles/26/", "http://swapi.co/api/vehicles/30/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/5/", "http://swapi.co/api/species/6/", "http://swapi.co/api/species/8/", "http://swapi.co/api/species/9/", "http://swapi.co/api/species/10/", "http://swapi.co/api/species/15/", "http://swapi.co/api/species/3/", "http://swapi.co/api/species/2/", "http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T10:39:33.255000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-11T09:46:05.220365Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["title", "episode_id", "opening_crawl", "director", "producer", "release_date", "characters", "planets", "starships", "vehicles", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["The Empire Strikes Back"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [5]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["It is a dark time for the\r\nRebellion. Although the Death\r\nStar has been destroyed,\r\nImperial troops have driven the\r\nRebel forces from their hidden\r\nbase and pursued them across\r\nthe galaxy.\r\n\r\nEvading the dreaded Imperial\r\nStarfleet, a group of freedom\r\nfighters led by Luke Skywalker\r\nhas established a new secret\r\nbase on the remote ice world\r\nof Hoth.\r\n\r\nThe evil lord Darth Vader,\r\nobsessed with finding young\r\nSkywalker, has dispatched\r\nthousands of remote probes into\r\nthe far reaches of space...."]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Irvin Kershner"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Gary Kutz, Rick McCallum"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1980-05-17"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/1/", "http://swapi.co/api/people/2/", "http://swapi.co/api/people/3/", "http://swapi.co/api/people/4/", "http://swapi.co/api/people/5/", "http://swapi.co/api/people/10/", "http://swapi.co/api/people/13/", "http://swapi.co/api/people/14/", "http://swapi.co/api/people/18/", "http://swapi.co/api/people/20/", "http://swapi.co/api/people/21/", "http://swapi.co/api/people/22/", "http://swapi.co/api/people/23/", "http://swapi.co/api/people/24/", "http://swapi.co/api/people/25/", "http://swapi.co/api/people/26/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/4/", "http://swapi.co/api/planets/5/", "http://swapi.co/api/planets/6/", "http://swapi.co/api/planets/27/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/10/", "http://swapi.co/api/starships/11/", "http://swapi.co/api/starships/12/", "http://swapi.co/api/starships/15/", "http://swapi.co/api/starships/21/", "http://swapi.co/api/starships/22/", "http://swapi.co/api/starships/23/", "http://swapi.co/api/starships/3/", "http://swapi.co/api/starships/17/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/8/", "http://swapi.co/api/vehicles/14/", "http://swapi.co/api/vehicles/16/", "http://swapi.co/api/vehicles/18/", "http://swapi.co/api/vehicles/19/", "http://swapi.co/api/vehicles/20/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/6/", "http://swapi.co/api/species/7/", "http://swapi.co/api/species/3/", "http://swapi.co/api/species/2/", "http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-12T11:26:24.656000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-11T09:46:31.433607Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/2/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["title", "episode_id", "opening_crawl", "director", "producer", "release_date", "characters", "planets", "starships", "species", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["The Force Awakens"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [7]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Luke Skywalker has vanished.\r\nIn his absence, the sinister\r\nFIRST ORDER has risen from\r\nthe ashes of the Empire\r\nand will not rest until\r\nSkywalker, the last Jedi,\r\nhas been destroyed.\r\n \r\nWith the support of the\r\nREPUBLIC, General Leia Organa\r\nleads a brave RESISTANCE.\r\nShe is desperate to find her\r\nbrother Luke and gain his\r\nhelp in restoring peace and\r\njustice to the galaxy.\r\n \r\nLeia has sent her most daring\r\npilot on a secret mission\r\nto Jakku, where an old ally\r\nhas discovered a clue to\r\nLuke's whereabouts...."]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["J. J. Abrams"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kathleen Kennedy, J. J. Abrams, Bryan Burk"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-12-11"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/1/", "http://swapi.co/api/people/3/", "http://swapi.co/api/people/5/", "http://swapi.co/api/people/13/", "http://swapi.co/api/people/14/", "http://swapi.co/api/people/27/", "http://swapi.co/api/people/84/", "http://swapi.co/api/people/85/", "http://swapi.co/api/people/86/", "http://swapi.co/api/people/87/", "http://swapi.co/api/people/88/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/61/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/77/", "http://swapi.co/api/starships/10/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/3/", "http://swapi.co/api/species/2/", "http://swapi.co/api/species/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-17T06:51:30.504780Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-12-17T14:31:47.617768Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/7/"]
            }
          ]
        }
      ]
    }

---

    {
      "type": "list",
      "attributes": {},
      "value": [
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Alderaan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["24"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["364"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["12500"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grasslands, mountains"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["40"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2000000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/5/", "http://swapi.co/api/people/68/", "http://swapi.co/api/people/81/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T11:35:48.479000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.420000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/2/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Yavin IV"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["24"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4818"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate, tropical"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["jungle, rainforests"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["8"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T11:37:19.144000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.421000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/3/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Hoth"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["23"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["549"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["7200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["frozen"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["tundra, ice caves, mountain ranges"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["100"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T11:39:13.934000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.423000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/4/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Dagobah"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["23"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["341"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["8900"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["murky"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["N/A"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["swamp, jungles"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["8"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T11:42:22.590000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.425000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/5/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Bespin"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["12"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5110"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["118000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.5 (surface), 1 standard (Cloud City)"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["gas giant"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/26/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T11:43:55.240000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.427000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/6/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Endor"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["18"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["402"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4900"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0.85 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["forests, mountains, lakes"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["8"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["30000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/30/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T11:50:29.349000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.429000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/7/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Naboo"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["26"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["312"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["12120"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grassy hills, swamps, forests, mountains"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["12"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4500000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/3/", "http://swapi.co/api/people/21/", "http://swapi.co/api/people/36/", "http://swapi.co/api/people/37/", "http://swapi.co/api/people/38/", "http://swapi.co/api/people/39/", "http://swapi.co/api/people/42/", "http://swapi.co/api/people/60/", "http://swapi.co/api/people/61/", "http://swapi.co/api/people/66/", "http://swapi.co/api/people/35/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T11:52:31.066000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.430000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/8/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Coruscant"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["24"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["368"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["12240"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["cityscape, mountains"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1000000000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/34/", "http://swapi.co/api/people/55/", "http://swapi.co/api/people/74/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T11:54:13.921000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.432000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/9/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Kamino"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["27"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["463"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["19720"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["ocean"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["100"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1000000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/22/", "http://swapi.co/api/people/72/", "http://swapi.co/api/people/73/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T12:45:06.577000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.434000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/10/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Geonosis"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["30"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["256"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["11370"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate, arid"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0.9 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["rock, desert, mountain, barren"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["100000000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/63/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T12:47:22.350000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.437000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/11/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Utapau"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["27"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["351"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["12900"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate, arid, windy"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["scrublands, savanna, canyons, sinkholes"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0.9"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["95000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/83/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T12:49:01.491000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.439000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/12/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Mustafar"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["36"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["412"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["hot"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["volcanoes, lava rivers, mountains, caves"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T12:50:16.526000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.440000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/13/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Kashyyyk"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["26"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["381"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["12765"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["tropical"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["jungle, forests, lakes, rivers"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["60"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["45000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/13/", "http://swapi.co/api/people/80/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T13:32:00.124000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.442000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/14/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Polis Massa"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["24"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["590"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["artificial temperate "]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0.56 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["airless asteroid"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T13:33:46.405000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.444000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/15/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Mygeeto"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["12"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["167"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10088"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["frigid"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["glaciers, mountains, ice canyons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["19000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T13:43:39.139000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.446000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/16/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Felucia"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["34"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["231"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["9100"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["hot, humid"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0.75 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fungus forests"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["8500000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T13:44:50.397000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.447000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/17/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Cato Neimoidia"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["25"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["278"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate, moist"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mountains, fields, forests, rock arches"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/33/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T13:46:28.704000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.449000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/18/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Saleucami"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["26"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["392"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["14920"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["hot"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["caves, desert, mountains, volcanoes"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1400000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T13:47:46.874000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.450000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/19/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Stewjon"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grass"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/10/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T16:16:26.566000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.452000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/20/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Eriadu"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["24"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["360"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["13490"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["polluted"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["cityscape"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["22000000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/12/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T16:26:54.384000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.454000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/21/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Corellia"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["25"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["329"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["11000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["plains, urban, hills, forests"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["70"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3000000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/14/", "http://swapi.co/api/people/18/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T16:49:12.453000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.456000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/22/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Rodia"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["29"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["305"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["7549"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["hot"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["jungles, oceans, urban, swamps"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["60"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1300000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/15/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T17:03:28.110000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.458000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/23/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Nal Hutta"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["87"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["413"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["12150"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["urban, oceans, swamps, bogs"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["7000000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/16/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T17:11:29.452000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.460000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/24/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Dantooine"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["25"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["378"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["9830"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["oceans, savannas, mountains, grasslands"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T17:23:29.896000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.461000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/25/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Bestine IV"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["26"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["680"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6400"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["rocky islands, oceans"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["98"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["62000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/19/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-12T11:16:55.078000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.463000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/26/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Ord Mantell"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["26"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["334"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["14050"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["plains, seas, mesas"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4000000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:23:41.661000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.464000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/27/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/20/", "http://swapi.co/api/people/23/", "http://swapi.co/api/people/29/", "http://swapi.co/api/people/32/", "http://swapi.co/api/people/75/", "http://swapi.co/api/people/84/", "http://swapi.co/api/people/85/", "http://swapi.co/api/people/86/", "http://swapi.co/api/people/87/", "http://swapi.co/api/people/88/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:25:59.569000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.466000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/28/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Trandosha"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["25"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["371"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["arid"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0.62 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mountains, seas, grasslands, deserts"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["42000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/24/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:53:47.695000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.468000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/29/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Socorro"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["326"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["arid"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["deserts, mountains"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["300000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/25/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:56:31.121000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.469000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/30/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Mon Cala"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["21"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["398"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["11030"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["oceans, reefs, islands"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["100"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["27000000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/27/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T11:07:01.792000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.471000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/31/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Chandrila"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["368"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["13500"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["plains, forests"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["40"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1200000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/28/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T11:11:51.872000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.472000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/32/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Sullust"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["263"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["12780"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["superheated"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mountains, volcanoes, rocky deserts"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["18500000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/31/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T11:25:40.243000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.474000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/33/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Toydaria"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["21"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["184"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["7900"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["swamps, lakes"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["11000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/40/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:47:54.403000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.476000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/34/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Malastare"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["26"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["201"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["18880"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["arid, temperate, tropical"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.56"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["swamps, deserts, jungles, mountains"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2000000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/41/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:52:13.106000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.478000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/35/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Dathomir"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["24"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["491"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10480"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0.9"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["forests, deserts, savannas"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/44/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T18:00:40.142000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.480000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/36/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Ryloth"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["30"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["305"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10600"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate, arid, subartic"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mountains, valleys, deserts, tundra"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1500000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/45/", "http://swapi.co/api/people/46/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T09:46:25.740000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.481000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/37/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Aleen Minor"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/47/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T09:52:23.452000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.483000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/38/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Vulpter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["22"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["391"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["14900"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate, artic"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["urban, barren"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["421000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/48/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T09:56:58.874000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.485000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/39/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Troiken"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["desert, tundra, rainforests, mountains"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/49/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:01:37.395000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.487000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/40/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Tund"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["48"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1770"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["12190"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["barren, ash"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/50/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:07:29.578000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.489000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/41/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Haruun Kal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["25"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["383"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10120"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0.98"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["toxic cloudsea, plateaus, volcanoes"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["705300"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/51/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:12:28.980000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.491000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/42/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Cerea"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["27"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["386"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["verdant"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["450000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/52/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:14:48.178000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.493000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/43/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Glee Anselm"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["33"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["206"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["15600"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["tropical, temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["lakes, islands, swamps, seas"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["80"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["500000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/53/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:18:26.110000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.495000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/44/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Iridonia"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["29"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["413"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["rocky canyons, acid pools"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/54/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:26:05.788000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.497000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/45/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Tholoth"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:28:31.117000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.498000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/46/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Iktotch"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["22"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["481"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["arid, rocky, windy"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["rocky"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/56/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:31:32.413000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.500000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/47/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Quermia"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/57/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:34:08.249000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.502000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/48/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Dorin"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["22"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["409"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["13400"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/58/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:48:36.141000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.504000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/49/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Champala"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["27"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["318"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["oceans, rainforests, plateaus"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3500000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/59/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:52:51.524000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.506000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/50/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Mirial"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["deserts"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/64/", "http://swapi.co/api/people/65/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T16:44:46.318000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.508000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/51/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Serenno"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["rainforests, rivers, mountains"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/67/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T16:52:13.357000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.510000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/52/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Concord Dawn"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["jungles, forests, deserts"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/69/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T16:54:39.909000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.512000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/53/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Zolan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/70/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T16:56:37.250000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.514000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/54/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Ojom"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["frigid"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["oceans, glaciers"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["100"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["500000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/71/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:27:41.286000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.516000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/55/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Skako"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["27"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["384"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["urban, vines"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["500000000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/76/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:50:47.864000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.517000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/56/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Muunilinst"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["28"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["412"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["13800"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["plains, forests, hills, mountains"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["25"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5000000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/77/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:57:47.420000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.519000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/57/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Shili"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["temperate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["cities, savannahs, seas, plains"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/78/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T18:43:14.049000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.521000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/58/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Kalee"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["23"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["378"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["13850"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["arid, temperate, tropical"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["rainforests, cliffs, canyons, seas"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4000000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/79/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T19:43:51.278000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.523000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/59/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Umbara"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/82/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:18:36.256000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:58:18.525000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/60/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "residents", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Tatooine"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["23"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["304"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10465"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["arid"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 standard"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["desert"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["200000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/1/", "http://swapi.co/api/people/2/", "http://swapi.co/api/people/4/", "http://swapi.co/api/people/6/", "http://swapi.co/api/people/7/", "http://swapi.co/api/people/8/", "http://swapi.co/api/people/9/", "http://swapi.co/api/people/11/", "http://swapi.co/api/people/43/", "http://swapi.co/api/people/62/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-09T13:50:49.641000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-21T20:48:04.175778Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/1/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "rotation_period", "orbital_period", "diameter", "climate", "gravity", "terrain", "surface_water", "population", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Jakku"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["deserts"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/7/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-17T06:55:57.556495Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-17T06:55:57.556551Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/61/"]
            }
          ]
        }
      ]
    }

---

    {
      "type": "list",
      "attributes": {},
      "value": [
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Hutt"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["gastropod"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["300"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["green, brown, tan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow, red"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/24/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Huttese"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/16/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T17:12:50.410000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.146000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/5/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Yoda's species"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["66"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["green, yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown, white"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown, green, yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["900"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/28/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Galactic basic"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/20/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:27:22.877000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.148000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/6/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Trandoshan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["reptile"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown, green"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow, orange"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/29/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Dosh"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/24/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T13:07:47.704000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.151000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/7/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Mon Calamari"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["amphibian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["160"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["red, blue, brown, magenta"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/31/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Mon Calamarian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/27/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T11:09:52.263000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.153000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/8/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Ewok"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["100"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["white, brown, black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["orange, brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/7/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Ewokese"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/30/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T11:22:00.285000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.155000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/9/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Sullustan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["pale"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/33/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Sullutese"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/31/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T11:26:20.103000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.157000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/10/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Neimodian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey, green"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["red, pink"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/18/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Neimoidia"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/33/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:07:31.319000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.160000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/11/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Gungan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["amphibian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["190"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown, green"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["orange"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/8/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Gungan basic"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/36/", "http://swapi.co/api/people/37/", "http://swapi.co/api/people/38/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:30:37.341000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.163000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/12/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Toydarian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["120"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue, green, grey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["91"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/34/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Toydarian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/40/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:48:56.893000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.165000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/13/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Dug"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["100"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown, purple, grey, red"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow, blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/35/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Dugese"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/41/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:53:11.214000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.167000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/14/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Twi'lek"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammals"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["orange, yellow, blue, green, pink, purple, tan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue, brown, orange, pink"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/37/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Twi'leki"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/45/", "http://swapi.co/api/people/46/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T09:48:02.406000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.169000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/15/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Aleena"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["reptile"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["80"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue, gray"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["79"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/38/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Aleena"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/47/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T09:53:16.481000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.171000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/16/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Vulptereen"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["100"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/39/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["vulpterish"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/48/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T09:57:33.128000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.173000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/17/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Xexto"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["125"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey, yellow, purple"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/40/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Xextese"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/49/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:02:13.915000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.175000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/18/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Toong"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey, green, yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["orange"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/41/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Tundan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/50/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:08:36.795000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.177000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/19/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Cerean"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["pale pink"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["red, blond, black, white"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["hazel"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/43/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Cerean"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/52/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:15:33.765000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.179000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/20/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Nautolan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["amphibian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["green, blue, brown, red"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["70"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/44/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Nautila"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/53/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:18:58.610000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.181000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/21/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Zabrak"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["pale, brown, red, orange, yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown, orange"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/45/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Zabraki"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/44/", "http://swapi.co/api/people/54/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:26:59.894000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.183000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/22/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Tholothian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["dark"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue, indigo"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/46/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/55/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:29:13.798000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.186000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/23/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Iktotchi"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["pink"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["orange"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/47/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Iktotchese"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/56/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:32:13.046000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.188000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/24/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Quermian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["240"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["white"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["86"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/48/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Quermian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/57/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:34:50.827000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.189000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/25/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Kel Dor"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["peach, orange, red"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black, silver"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["70"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/49/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kel Dor"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/58/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:49:21.692000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.191000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/26/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Chagrian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["amphibian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["190"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/50/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Chagria"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/59/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:53:28.795000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.193000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/27/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Geonosian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["insectoid"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["178"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["green, brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["green, hazel"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/11/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Geonosian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/63/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T16:40:45.618000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.195000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/28/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Mirialan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow, green"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black, brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue, green, red, yellow, brown, orange"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/51/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Mirialan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/64/", "http://swapi.co/api/people/65/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T16:46:48.290000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.197000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/29/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Clawdite"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["reptilian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["green, yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["70"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/54/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Clawdite"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/70/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T16:57:46.171000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.199000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/30/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Besalisk"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["amphibian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["178"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["75"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/55/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["besalisk"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/71/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:28:28.821000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.200000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/31/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Kaminoan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["amphibian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["220"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey, blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["80"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/10/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kaminoan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/72/", "http://swapi.co/api/people/73/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:31:24.838000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.202000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/32/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Skakoan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey, green"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/56/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Skakoan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/76/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:53:54.515000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.204000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/33/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Muun"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["190"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey, white"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["100"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/57/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Muun"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/77/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:58:19.088000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.207000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/34/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Togruta"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["red, white, orange, yellow, green, blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["red, orange, yellow, green, blue, black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["94"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/58/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Togruti"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/78/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T18:44:03.246000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.209000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/35/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Kaleesh"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["reptile"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["170"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown, orange, tan"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yellow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["80"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/59/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kaleesh"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/79/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T19:45:42.537000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.210000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/36/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Pau'an"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["190"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["grey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["700"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/12/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Utapese"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/83/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:35:06.777000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T21:36:42.212000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/37/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Wookiee"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["210"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["gray"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black, brown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blue, green, yellow, brown, golden, red"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["400"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/14/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Shyriiwook"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/13/", "http://swapi.co/api/people/80/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/7/", "http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T16:44:31.486000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-01-30T21:23:03.074598Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/3/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Droid"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["artificial"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["indefinite"]
            },
            {
              "type": "NULL"
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/2/", "http://swapi.co/api/people/3/", "http://swapi.co/api/people/8/", "http://swapi.co/api/people/23/", "http://swapi.co/api/people/87/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/7/", "http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T15:16:16.259000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-17T06:59:43.869528Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/2/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Human"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["mammal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["caucasian, black, asian, hispanic"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["blonde, brown, black, red"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["brown, blue, green, hazel, grey, amber"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["120"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/9/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Galactic Basic"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/1/", "http://swapi.co/api/people/4/", "http://swapi.co/api/people/5/", "http://swapi.co/api/people/6/", "http://swapi.co/api/people/7/", "http://swapi.co/api/people/9/", "http://swapi.co/api/people/10/", "http://swapi.co/api/people/11/", "http://swapi.co/api/people/12/", "http://swapi.co/api/people/14/", "http://swapi.co/api/people/18/", "http://swapi.co/api/people/19/", "http://swapi.co/api/people/21/", "http://swapi.co/api/people/22/", "http://swapi.co/api/people/25/", "http://swapi.co/api/people/26/", "http://swapi.co/api/people/28/", "http://swapi.co/api/people/29/", "http://swapi.co/api/people/32/", "http://swapi.co/api/people/34/", "http://swapi.co/api/people/43/", "http://swapi.co/api/people/51/", "http://swapi.co/api/people/60/", "http://swapi.co/api/people/61/", "http://swapi.co/api/people/62/", "http://swapi.co/api/people/66/", "http://swapi.co/api/people/67/", "http://swapi.co/api/people/68/", "http://swapi.co/api/people/69/", "http://swapi.co/api/people/74/", "http://swapi.co/api/people/81/", "http://swapi.co/api/people/84/", "http://swapi.co/api/people/85/", "http://swapi.co/api/people/86/", "http://swapi.co/api/people/35/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/7/", "http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T13:52:11.567000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-17T06:59:55.850671Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/1/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "classification", "designation", "average_height", "skin_colors", "hair_colors", "eye_colors", "average_lifespan", "homeworld", "language", "people", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Rodian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sentient"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["reptilian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["170"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["green, blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["black"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/planets/23/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Galactic Basic"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/15/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T17:05:26.471000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2016-07-19T13:27:03.156498Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/species/4/"]
            }
          ]
        }
      ]
    }

---

    {
      "type": "list",
      "attributes": {},
      "value": [
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Sand Crawler"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Digger Crawler"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Corellia Mining Corporation"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["150000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["36.8"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["30"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["46"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["30"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["50000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2 months"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["wheeled"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T15:36:25.724000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:15.523587Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/4/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["T-16 skyhopper"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["T-16 skyhopper"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Incom Corporation"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["14500"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10.4"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["50"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["repulsorcraft"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T16:01:52.434000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:15.552614Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/6/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["X-34 landspeeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["X-34 landspeeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["SoroSuub Corporation"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10550"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3.4"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["250"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["repulsorcraft"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T16:13:52.586000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:15.583700Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/7/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["TIE/LN starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Twin Ion Engine/Ln Starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Sienar Fleet Systems"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6.4"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["65"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T16:33:52.860000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:15.606149Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/8/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Snowspeeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["t-47 airspeeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Incom corporation"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4.5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["650"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["airspeeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/1/", "http://swapi.co/api/people/18/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:22:12Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:15.623033Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/14/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["TIE bomber"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["TIE/sa bomber"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Sienar Fleet Systems"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["7.8"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["850"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["space/planetary bomber"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:33:15.838000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:15.667730Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/16/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["AT-AT"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["All Terrain Armored Transport"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kuat Drive Yards, Imperial Department of Military Research"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["60"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["40"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["assault walker"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:38:25.937000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:15.714673Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/18/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["AT-ST"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["All Terrain Scout Transport"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kuat Drive Yards, Imperial Department of Military Research"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["90"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["walker"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/13/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:46:42.384000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:15.761584Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/19/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Storm IV Twin-Pod cloud car"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Storm IV Twin-Pod"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Bespin Motors"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["75000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["7"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1500"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 day"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["repulsorcraft"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:58:50.530000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:15.783232Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/20/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Sail barge"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Modified Luxury Sail Barge"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Ubrikkian Industries Custom Vehicle Division"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["285000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["30"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["100"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["26"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["500"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Live food tanks"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["sail barge"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T10:44:14.217000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:15.807906Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/24/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Bantha-II cargo skiff"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Bantha-II"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Ubrikkian Industries"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["8000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["9.5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["250"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["16"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["135000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 day"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["repulsorcraft cargo skiff"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T10:48:03.208000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:15.845988Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/25/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["TIE/IN interceptor"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Twin Ion Engine Interceptor"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Sienar Fleet Systems"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["9.6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1250"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["75"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T10:50:28.225000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:15.882388Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/26/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Imperial Speeder Bike"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["74-Z speeder bike"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Aratech Repulsor Company"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["8000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["360"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 day"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["speeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/1/", "http://swapi.co/api/people/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T11:20:04.625000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:15.920537Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/30/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Vulture Droid"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Vulture-class droid starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Haor Chall Engineering, Baktoid Armor Workshop"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3.5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:09:53.584000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:15.953870Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/33/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Multi-Troop Transport"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Multi-Troop Transport"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Baktoid Armor Workshop"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["138000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["31"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["35"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["112"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["12000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["repulsorcraft"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:12:04.400000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:15.975171Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/34/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Armored Assault Tank"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Armoured Assault Tank"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Baktoid Armor Workshop"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["9.75"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["55"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["repulsorcraft"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:13:29.799000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:15.984817Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/35/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Single Trooper Aerial Platform"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Single Trooper Aerial Platform"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Baktoid Armor Workshop"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2500"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["400"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["repulsorcraft"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:15:09.511000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.008594Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/36/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["C-9979 landing craft"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["C-9979 landing craft"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Haor Chall Engineering"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["200000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["210"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["587"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["140"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["284"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1800000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 day"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["landing craft"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:20:36.373000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.033738Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/37/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Tribubble bongo"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Tribubble bongo"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Otoh Gunga Bongameken Cooperative"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["15"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["85"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1600"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["submarine"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/10/", "http://swapi.co/api/people/32/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:37:37.924000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.072083Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/38/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Sith speeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["FC-20 speeder bike"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Razalon"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["speeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/44/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T10:09:56.095000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.095041Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/42/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Zephyr-G swoop bike"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Zephyr-G swoop bike"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Mobquet Swoops and Speeders"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5750"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3.68"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["350"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["repulsorcraft"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/11/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T16:24:16.026000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.117652Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/44/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Koro-2 Exodrive airspeeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Koro-2 Exodrive airspeeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Desler Gizh Outworld Mobility Corporation"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6.6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["800"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["80"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["airspeeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/70/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:17:33.526000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.140018Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/45/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["XJ-6 airspeeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["XJ-6 airspeeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Narglatch AirTech prefabricated kit"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6.23"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["720"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["airspeeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/11/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:19:19.991000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.150194Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/46/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["LAAT/i"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Low Altitude Assault Transport/infrantry"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Rothana Heavy Engineering"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["17.4"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["620"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["30"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["170"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["gunship"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T18:01:21.014000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.181363Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/50/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["LAAT/c"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Low Altitude Assault Transport/carrier"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Rothana Heavy Engineering"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["28.82"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["620"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["40000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["gunship"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T18:02:46.802000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.229733Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/51/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Tsmeu-6 personal wheel bike"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Tsmeu-6 personal wheel bike"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Z-Gomot Ternbuell Guppat Corporation"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["15000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3.5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["330"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["wheeled walker"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/79/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T19:43:54.870000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.422662Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/60/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Emergency Firespeeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Fire suppression speeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fire suppression ship"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T19:50:58.559000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.450655Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/62/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Droid tri-fighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["tri-fighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Colla Designs, Phlac-Arphocc Automata Industries"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5.4"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["droid starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:05:19.992000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.478901Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/67/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Oevvaor jet catamaran"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Oevvaor jet catamaran"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Appazanna Engineering Works"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["12125"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["15.1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["420"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["50"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["airspeeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:20:53.931000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.517049Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/69/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Raddaugh Gnasp fluttercraft"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Raddaugh Gnasp fluttercraft"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Appazanna Engineering Works"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["14750"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["7"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["310"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["air speeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:21:55.648000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.547708Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/70/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Clone turbo tank"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["HAVw A6 Juggernaut"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kuat Drive Yards"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["350000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["49.4"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["160"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["300"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["30000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["wheeled walker"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:24:45.587000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.571079Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/71/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Corporate Alliance tank droid"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["NR-N99 Persuader-class droid enforcer"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Techno Union"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["49000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10.96"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["100"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["droid tank"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:26:55.522000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.612902Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/72/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Droid gunship"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["HMP droid gunship"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Baktoid Fleet Ordnance, Haor Chall Engineering"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["60000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["12.3"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["820"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["none"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["airspeeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:32:05.687000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.643329Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/73/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["AT-RT"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["All Terrain Recon Transport"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kuat Drive Yards"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["40000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3.2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["90"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 day"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["walker"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:47:49.189000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.672821Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/76/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["AT-TE"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["All Terrain Tactical Enforcer"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Rothana Heavy Engineering, Kuat Drive Yards"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["13.2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["60"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["36"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["21 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["walker"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T18:10:07.560000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.293771Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/53/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["SPHA"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Self-Propelled Heavy Artillery"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Rothana Heavy Engineering"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["140"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["35"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["25"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["30"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["500"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["7 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["walker"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T18:12:32.315000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.311761Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/54/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Flitknot speeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Flitknot speeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Huppla Pasa Tisc Shipwrights Collective"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["8000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["634"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["speeder"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/67/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T18:15:20.312000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.335005Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/55/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Neimoidian shuttle"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Sheathipede-class transport shuttle"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Haor Chall Engineering"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["880"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["7 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["transport"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T18:25:44.912000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.366134Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/56/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "vehicle_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Geonosian starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Nantex-class territorial defense"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Huppla Pasa Tisc Shipwrights Collective"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["9.8"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T18:34:12.541000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T18:21:16.390980Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/vehicles/57/"]
            }
          ]
        }
      ]
    }

---

    {
      "type": "list",
      "attributes": {},
      "value": [
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Sentinel-class landing craft"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Sentinel-class landing craft"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Sienar Fleet Systems, Cyngus Spaceworks"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["240000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["38"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["75"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 month"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["70"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["landing craft"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T15:48:00.586000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:44.431407Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/5/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Death Star"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["DS-1 Orbital Battle Station"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Imperial Department of Military Research, Sienar Fleet Systems"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1000000000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["120000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["342953"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["843342"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1000000000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3 years"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Deep Space Mobile Battlestation"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T16:36:50.509000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:44.452589Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/9/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Millennium Falcon"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["YT-1300 light freighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Corellian Engineering Corporation"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["100000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["34.37"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1050"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["100000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2 months"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0.5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["75"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Light freighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/13/", "http://swapi.co/api/people/14/", "http://swapi.co/api/people/25/", "http://swapi.co/api/people/31/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/7/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T16:59:45.094000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:44.464156Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/10/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Y-wing"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["BTL Y-wing"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Koensayr Manufacturing"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["134999"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["14"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1000km"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["110"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 week"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["80"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["assault starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-12T11:00:39.817000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:44.479706Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/11/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["X-wing"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["T-65 X-wing"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Incom Corporation"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["149999"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["12.5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1050"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["110"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 week"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["100"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/1/", "http://swapi.co/api/people/9/", "http://swapi.co/api/people/18/", "http://swapi.co/api/people/19/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-12T11:19:05.340000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:44.491233Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/12/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["TIE Advanced x1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Twin Ion Engine Advanced x1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Sienar Fleet Systems"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["9.2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["150"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["105"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-12T11:21:32.991000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:44.549047Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/13/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Executor"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Executor-class star dreadnought"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kuat Drive Yards, Fondor Shipyards"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1143350000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["19,000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["279144"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["38000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["250000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6 years"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["40"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Star dreadnought"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:31:42.547000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:44.638231Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/15/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Slave 1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Firespray-31-class patrol and attack"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kuat Systems Engineering"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["21.5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["70000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 month"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["70"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Patrol craft"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/22/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T13:00:56.332000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:44.716273Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/21/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Imperial shuttle"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Lambda-class T-4a shuttle"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Sienar Fleet Systems"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["240000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["850"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["80000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2 months"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["50"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Armed government transport"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/1/", "http://swapi.co/api/people/13/", "http://swapi.co/api/people/14/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T13:04:47.235000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:44.795405Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/22/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["EF76 Nebulon-B escort frigate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["EF76 Nebulon-B escort frigate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kuat Drive Yards"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["8500000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["300"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["800"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["854"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["75"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2 years"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["40"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Escort ship"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T13:06:30.813000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:44.848329Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/23/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Calamari Cruiser"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["MC80 Liberty type Star Cruiser"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Mon Calamari shipyards"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["104000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5400"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2 years"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["60"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Star Cruiser"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T10:54:57.804000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:44.957852Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/27/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["A-wing"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["RZ-1 A-wing Interceptor"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Alliance Underground Engineering, Incom Corporation"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["175000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["9.6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1300"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["40"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 week"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["120"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/29/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T11:16:34.542000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:44.978754Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/28/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["B-wing"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A/SF-01 B-wing starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Slayn & Korpil"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["220000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["16.9"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["950"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["45"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 week"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["91"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Assault Starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-18T11:18:04.763000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.011193Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/29/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Republic Cruiser"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Consular-class cruiser"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Corellian Engineering Corporation"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["115"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["900"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["9"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["16"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Space cruiser"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:01:31.488000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.027308Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/31/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Naboo fighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["N-1 starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Theed Palace Space Vessel Engineering Corps"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["200000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["11"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1100"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["65"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["7 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/11/", "http://swapi.co/api/people/60/", "http://swapi.co/api/people/35/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:39:17.582000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.079452Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/39/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Naboo Royal Starship"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["J-type 327 Nubian royal starship"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Theed Palace Space Vessel Engineering Corps, Nubia Star Drives"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["76"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["920"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["8"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.8"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yacht"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/39/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:45:03.506000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.091925Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/40/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Scimitar"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Star Courier"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Republic Sienar Systems"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["55000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["26.5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1180"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2500000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["30 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Space Transport"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/44/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/4/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T09:39:56.116000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.105522Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/41/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["J-type diplomatic barge"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["J-type diplomatic barge"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Theed Palace Space Vessel Engineering Corps, Nubia Star Drives"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["39"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["10"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 year"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0.7"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Diplomatic barge"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T11:05:51.237000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.124386Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/43/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["AA-9 Coruscant freighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Botajef AA-9 Freighter-Liner"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Botajef Shipyards"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["390"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["30000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["freighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:24:23.509000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.135987Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/47/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Jedi starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Delta-7 Aethersprite-class interceptor"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kuat Systems Engineering"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["180000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["8"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1150"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["60"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["7 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/10/", "http://swapi.co/api/people/58/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:35:23.906000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.147746Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/48/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["H-type Nubian yacht"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["H-type Nubian yacht"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Theed Palace Space Vessel Engineering Corps"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["47.9"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["8000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0.9"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yacht"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/35/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T17:46:46.847000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.158969Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/49/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Star Destroyer"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Imperial I-class Star Destroyer"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kuat Drive Yards"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["150000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1,600"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["975"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["47060"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["36000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2 years"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["60"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Star Destroyer"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T15:08:19.848000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:44.410941Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/3/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Trade Federation cruiser"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Providence-class carrier/destroyer"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Rendili StarDrive, Free Dac Volunteers Engineering corps."]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["125000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1088"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1050"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["600"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["48247"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["50000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4 years"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["capital ship"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/10/", "http://swapi.co/api/people/11/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T19:40:21.902000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.195165Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/59/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Theta-class T-2c shuttle"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Theta-class T-2c shuttle"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Cygnus Spaceworks"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["18.5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["16"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["50000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["56 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["transport"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T19:48:40.409000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.208584Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/61/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["T-70 X-wing fighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["T-70 X-wing fighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Incom"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["fighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/86/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/7/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-17T06:58:50.614475Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2015-04-17T06:58:50.614528Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/77/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Rebel transport"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["GR-75 medium transport"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Gallofree Yards, Inc."]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["90"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["650"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["90"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["19000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6 months"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Medium transport"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/3/", "http://swapi.co/api/films/2/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-15T12:34:52.264000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:44.680838Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/17/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Droid control ship"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Lucrehulk-class Droid Control Ship"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Hoersch-Kessel Drive, Inc."]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3170"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["n/a"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["175"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["139000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["4000000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["500 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Droid control ship"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/", "http://swapi.co/api/films/4/", "http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-19T17:04:06.323000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.042900Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/32/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Republic Assault ship"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Acclamator I-class assault ship"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Rothana Heavy Engineering"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["752"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["700"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["16000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["11250000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2 years"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0.6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["assault ship"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T18:08:42.926000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.171653Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/52/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Solar Sailer"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Punworcca 116-class interstellar sloop"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Huppla Pasa Tisc Shipwrights Collective"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["35700"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["15.2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1600"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["11"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["240"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["7 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yacht"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/5/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T18:37:56.969000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.183075Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/58/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Republic attack cruiser"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Senator-class Star Destroyer"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kuat Drive Yards, Allanteen Six shipyards"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["59000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1137"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["975"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["7400"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["20000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2 years"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["star destroyer"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T19:52:56.232000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.224540Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/63/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Naboo star skiff"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["J-type star skiff"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Theed Palace Space Vessel Engineering Corps/Nubia Star Drives, Incorporated"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["29.2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1050"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0.5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["yacht"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/10/", "http://swapi.co/api/people/35/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T19:55:15.396000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.258859Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/64/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Jedi Interceptor"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Eta-2 Actis-class light interceptor"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kuat Systems Engineering"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["320000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5.47"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1500"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["60"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/10/", "http://swapi.co/api/people/11/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T19:56:57.468000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.272349Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/65/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["arc-170"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Aggressive Reconnaissance-170 starfighte"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Incom Corporation, Subpro Corporation"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["155000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["14.5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["110"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["5 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["100"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:03:48.603000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.287214Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/66/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Banking clan frigte"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Munificent-class star frigate"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Hoersch-Kessel Drive, Inc, Gwori Revolutionary Industries"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["57000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["825"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["200"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["40000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2 years"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["cruiser"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:07:11.538000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.361585Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/68/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "pilots", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["Belbullab-22 starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Belbullab-22 starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Feethan Ottraw Scalable Assemblies"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["168000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6.71"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1100"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["140"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["7 days"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/people/10/", "http://swapi.co/api/people/79/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:38:05.031000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.381900Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/74/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["V-wing"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Alpha-3 Nimbus-class V-wing starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kuat Systems Engineering"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["102500"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["7.9"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1050"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["60"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["15 hours"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["starfighter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-20T20:43:04.349000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.396711Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/75/"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["name", "model", "manufacturer", "cost_in_credits", "length", "max_atmosphering_speed", "crew", "passengers", "cargo_capacity", "consumables", "hyperdrive_rating", "MGLT", "starship_class", "films", "created", "edited", "url"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["CR90 corvette"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["CR90 corvette"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Corellian Engineering Corporation"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3500000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["150"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["950"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["165"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["600"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["3000000"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["1 year"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2.0"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["60"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["corvette"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/films/6/", "http://swapi.co/api/films/3/", "http://swapi.co/api/films/1/"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-10T14:20:33.369000Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["2014-12-22T17:35:45.408368Z"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["http://swapi.co/api/starships/2/"]
            }
          ]
        }
      ]
    }

