# got_chars list hasn't changed

    {
      "type": "list",
      "attributes": {},
      "value": [
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/1022"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [1022]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Theon Greyjoy"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Ironborn"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 278 AC or 279 AC, at Pyke"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Prince of Winterfell", "Lord of the Iron Islands (by law of the green lands)"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Prince of Fools", "Theon Turncloak", "Reek", "Theon Kinslayer"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Greyjoy of Pyke"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Storm of Swords", "A Feast for Crows"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Clash of Kings", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 1", "Season 2", "Season 3", "Season 4", "Season 5", "Season 6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Alfie Allen"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/1052"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [1052]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Tyrion Lannister"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 273 AC, at Casterly Rock"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Acting Hand of the King (former)", "Master of Coin (former)"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["The Imp", "Halfman", "The boyman", "Giant of Lannister", "Lord Tywin's Doom", "Lord Tywin's Bane", "Yollo", "Hugor Hill", "No-Nose", "Freak", "Dwarf"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/2044"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Lannister of Casterly Rock"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Feast for Crows", "The World of Ice and Fire"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Storm of Swords", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 1", "Season 2", "Season 3", "Season 4", "Season 5", "Season 6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Peter Dinklage"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/1074"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [1074]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Victarion Greyjoy"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Ironborn"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 268 AC or before, at Pyke"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Lord Captain of the Iron Fleet", "Master of the Iron Victory"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["The Iron Captain"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Greyjoy of Pyke"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Storm of Swords"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Feast for Crows", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/1109"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [1109]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Will"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 297 AC, at Haunted Forest"]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [false]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "list",
              "attributes": {},
              "value": []
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Clash of Kings"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Bronson Webb"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/1166"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [1166]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Areo Hotah"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Norvoshi"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 257 AC or before, at Norvos"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Captain of the Guard at Sunspear"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Nymeros Martell of Sunspear"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Storm of Swords"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Feast for Crows", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 5", "Season 6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["DeObia Oparei"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/1267"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [1267]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Chett"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["At Hag's Mire"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 299 AC, at Fist of the First Men"]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [false]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "list",
              "attributes": {},
              "value": []
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Storm of Swords"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/1295"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [1295]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Cressen"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 219 AC or 220 AC"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 299 AC, at Dragonstone"]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [false]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Maester"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "list",
              "attributes": {},
              "value": []
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Storm of Swords", "A Feast for Crows"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Clash of Kings"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 2"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Oliver Ford"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/130"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [130]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Arianne Martell"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Dornish"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 276 AC, at Sunspear"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Princess of Dorne"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Nymeros Martell of Sunspear"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Storm of Swords", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Feast for Crows"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/1303"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [1303]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Daenerys Targaryen"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Valyrian"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 284 AC, at Dragonstone"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Queen of the Andals and the Rhoynar and the First Men, Lord of the Seven Kingdoms", "Khaleesi of the Great Grass Sea", "Breaker of Shackles/Chains", "Queen of Meereen", "Princess of Dragonstone"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Dany", "Daenerys Stormborn", "The Unburnt", "Mother of Dragons", "Mother", "Mhysa", "The Silver Queen", "Silver Lady", "Dragonmother", "The Dragon Queen", "The Mad King's daughter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/1346"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Targaryen of King's Landing"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Feast for Crows"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Storm of Swords", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 1", "Season 2", "Season 3", "Season 4", "Season 5", "Season 6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Emilia Clarke"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/1319"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [1319]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Davos Seaworth"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Westeros"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 260 AC or before, at King's Landing"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Ser", "Lord of the Rainwood", "Admiral of the Narrow Sea", "Hand of the King"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Onion Knight", "Davos Shorthand", "Ser Onions", "Onion Lord", "Smuggler"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/1676"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Baratheon of Dragonstone", "House Seaworth of Cape Wrath"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Feast for Crows"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Clash of Kings", "A Storm of Swords", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 2", "Season 3", "Season 4", "Season 5", "Season 6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Liam Cunningham"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/148"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [148]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Arya Stark"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Northmen"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 289 AC, at Winterfell"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Princess"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Arya Horseface", "Arya Underfoot", "Arry", "Lumpyface", "Lumpyhead", "Stickboy", "Weasel", "Nymeria", "Squan", "Saltb", "Cat of the Canaly", "Bets", "The Blind Girh", "The Ugly Little Girl", "Mercedenl", "Mercye"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Stark of Winterfell"]
            },
            {
              "type": "list",
              "attributes": {},
              "value": []
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Storm of Swords", "A Feast for Crows", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 1", "Season 2", "Season 3", "Season 4", "Season 5", "Season 6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Maisie Williams"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/149"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [149]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Arys Oakheart"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Reach"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["At Old Oak"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 300 AC, at the Greenblood"]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [false]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Ser"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Oakheart of Old Oak"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Storm of Swords", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Feast for Crows"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/150"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [150]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Asha Greyjoy"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Ironborn"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 275 AC or 276 AC, at Pyke"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Princess", "Captain of the Black Wind", "Conqueror of Deepwood Motte"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Esgred", "The Kraken's Daughter"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/1372"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Greyjoy of Pyke", "House Ironmaker"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Feast for Crows", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 2", "Season 3", "Season 4"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Gemma Whelan"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/168"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [168]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Barristan Selmy"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Westeros"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 237 AC"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Ser", "Hand of the Queen"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Barristan the Bold", "Arstan Whitebeard", "Ser Grandfather", "Barristan the Old", "Old Ser"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Selmy of Harvest Hall", "House Targaryen of King's Landing"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Storm of Swords", "A Feast for Crows", "The World of Ice and Fire"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 1", "Season 3", "Season 4", "Season 5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Ian McElhinney"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/2066"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [2066]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Varamyr"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Free Folk"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["At a village Beyond the Wall"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 300 AC, at a village Beyond the Wall"]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [false]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Varamyr Sixskins", "Haggon", "Lump"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "list",
              "attributes": {},
              "value": []
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Storm of Swords"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/208"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [208]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Brandon Stark"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Northmen"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 290 AC, at Winterfell"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Prince of Winterfell"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Bran", "Bran the Broken", "The Winged Wolf"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Stark of Winterfell"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Feast for Crows"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Storm of Swords", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 1", "Season 2", "Season 3", "Season 4", "Season 6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Isaac Hempstead-Wright"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/216"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [216]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Brienne of Tarth"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 280 AC"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["The Maid of Tarth", "Brienne the Beauty", "Brienne the Blue"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Baratheon of Storm's End", "House Stark of Winterfell", "House Tarth of Evenfall Hall"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Clash of Kings", "A Storm of Swords", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Feast for Crows"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 2", "Season 3", "Season 4", "Season 5", "Season 6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Gwendoline Christie"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/232"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [232]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Catelyn Stark"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Rivermen"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 264 AC, at Riverrun"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 299 AC, at the Twins"]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [false]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Lady of Winterfell"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Catelyn Tully", "Lady Stoneheart", "The Silent Sistet", "Mother Mercilesr", "The Hangwomans"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/339"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Stark of Winterfell", "House Tully of Riverrun"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Feast for Crows", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Storm of Swords"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 1", "Season 2", "Season 3"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Michelle Fairley"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/238"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [238]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Cersei Lannister"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Westerman"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 266 AC, at Casterly Rock"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Light of the West", "Queen Dowager", "Protector of the Realm", "Lady of Casterly Rock", "Queen Regent"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/901"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Lannister of Casterly Rock"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Storm of Swords"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Feast for Crows", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 1", "Season 2", "Season 3", "Season 4", "Season 5", "Season 6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Lena Headey"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/339"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [339]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Eddard Stark"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Northmen"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 263 AC, at Winterfell"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 299 AC, at Great Sept of Baelor in King's Landing"]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [false]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Lord of Winterfell", "Warden of the North", "Hand of the King", "Protector of the Realm", "Regent"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Ned", "The Ned", "The Quiet Wolf"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/232"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Stark of Winterfell"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Clash of Kings", "A Storm of Swords", "A Feast for Crows", "A Dance with Dragons", "The World of Ice and Fire"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 1", "Season 6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Sean Bean", "Sebastian Croft", "Robert Aramayo"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/529"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [529]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Jaime Lannister"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Westerlands"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 266 AC, at Casterly Rock"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Ser", "Lord Commander of the Kingsguard", "Warden of the East (formerly)"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["The Kingslayer", "The Lion of Lannister", "The Young Lion", "Cripple"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Lannister of Casterly Rock"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Storm of Swords", "A Feast for Crows", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 1", "Season 2", "Season 3", "Season 4", "Season 5"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Nikolaj Coster-Waldau"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/576"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [576]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Jon Connington"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Stormlands"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In or between 263 AC and 265 AC"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Lord of Griffin's Roost", "Hand of the King", "Hand of the True King"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Griffthe Mad King's Hand"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Connington of Griffin's Roost", "House Targaryen of King's Landing"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Storm of Swords", "A Feast for Crows", "The World of Ice and Fire"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/583"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [583]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Jon Snow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Northmen"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 283 AC"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Lord Commander of the Night's Watch"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Lord Snow", "Ned Stark's Bastard", "The Snow of Winterfell", "The Crow-Come-Over", "The 998th Lord Commander of the Night's Watch", "The Bastard of Winterfell", "The Black Bastard of the Wall", "Lord Crow"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Stark of Winterfell"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Feast for Crows"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Storm of Swords", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 1", "Season 2", "Season 3", "Season 4", "Season 5", "Season 6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kit Harington"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/60"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [60]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Aeron Greyjoy"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Ironborn"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In or between 269 AC and 273 AC, at Pyke"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Priest of the Drowned God", "Captain of the Golden Storm (formerly)"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["The Damphair", "Aeron Damphair"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Greyjoy of Pyke"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Storm of Swords", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Feast for Crows"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Michael Feast"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/605"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [605]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Kevan Lannister"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 244 AC"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 300 AC, at King's Landing"]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [false]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Ser", "Master of laws", "Lord Regent", "Protector of the Realm"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/327"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Lannister of Casterly Rock"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Storm of Swords", "A Feast for Crows"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 1", "Season 2", "Season 5", "Season 6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Ian Gelder"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/743"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [743]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Melisandre"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Asshai"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["At Unknown"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["The Red Priestess", "The Red Woman", "The King's Red Shadow", "Lady Red", "Lot Seven"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "list",
              "attributes": {},
              "value": []
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Clash of Kings", "A Storm of Swords", "A Feast for Crows"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 2", "Season 3", "Season 4", "Season 5", "Season 6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Carice van Houten"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/751"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [751]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Merrett Frey"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Rivermen"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 262 AC"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 300 AC, at Near Oldstones"]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [false]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Merrett Muttonhead"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/712"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Frey of the Crossing"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Feast for Crows", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Storm of Swords"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/844"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [844]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Quentyn Martell"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Dornish"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 281 AC, at Sunspear, Dorne"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 300 AC, at Meereen"]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [false]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Prince"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Frog", "Prince Frog", "The prince who came too late", "The Dragonrider"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Nymeros Martell of Sunspear"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Storm of Swords", "A Feast for Crows"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/954"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [954]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Samwell Tarly"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Male"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Andal"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 283 AC, at Horn Hill"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Sam", "Ser Piggy", "Prince Pork-chop", "Lady Piggy", "Sam the Slayer", "Black Sam", "Lord of Ham"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Tarly of Horn Hill"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Storm of Swords", "A Feast for Crows"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 1", "Season 2", "Season 3", "Season 4", "Season 5", "Season 6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["John Bradley-West"]
            }
          ]
        },
        {
          "type": "list",
          "attributes": {
            "names": {
              "type": "character",
              "attributes": {},
              "value": ["url", "id", "name", "gender", "culture", "born", "died", "alive", "titles", "aliases", "father", "mother", "spouse", "allegiances", "books", "povBooks", "tvSeries", "playedBy"]
            }
          },
          "value": [
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/957"]
            },
            {
              "type": "integer",
              "attributes": {},
              "value": [957]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Sansa Stark"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Female"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Northmen"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["In 286 AC, at Winterfell"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "logical",
              "attributes": {},
              "value": [true]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Princess"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Little bird", "Alayne Stone", "Jonquil"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": [""]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["https://www.anapioficeandfire.com/api/characters/1052"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["House Baelish of Harrenhal", "House Stark of Winterfell"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Dance with Dragons"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["A Game of Thrones", "A Clash of Kings", "A Storm of Swords", "A Feast for Crows"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Season 1", "Season 2", "Season 3", "Season 4", "Season 5", "Season 6"]
            },
            {
              "type": "character",
              "attributes": {},
              "value": ["Sophie Turner"]
            }
          ]
        }
      ]
    }

