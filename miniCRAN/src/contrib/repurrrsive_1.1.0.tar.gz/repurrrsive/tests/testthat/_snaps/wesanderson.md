# wesanderson list hasn't changed

    {
      "type": "list",
      "attributes": {
        "names": {
          "type": "character",
          "attributes": {},
          "value": ["GrandBudapest", "Moonrise1", "Royal1", "Moonrise2", "Cavalcanti", "Royal2", "GrandBudapest2", "Moonrise3", "Chevalier", "Zissou", "FantasticFox", "Darjeeling", "Rushmore", "BottleRocket", "Darjeeling2"]
        }
      },
      "value": [
        {
          "type": "character",
          "attributes": {},
          "value": ["#F1BB7B", "#FD6467", "#5B1A18", "#D67236"]
        },
        {
          "type": "character",
          "attributes": {},
          "value": ["#F3DF6C", "#CEAB07", "#D5D5D3", "#24281A"]
        },
        {
          "type": "character",
          "attributes": {},
          "value": ["#899DA4", "#C93312", "#FAEFD1", "#DC863B"]
        },
        {
          "type": "character",
          "attributes": {},
          "value": ["#798E87", "#C27D38", "#CCC591", "#29211F"]
        },
        {
          "type": "character",
          "attributes": {},
          "value": ["#D8B70A", "#02401B", "#A2A475", "#81A88D", "#972D15"]
        },
        {
          "type": "character",
          "attributes": {},
          "value": ["#9A8822", "#F5CDB4", "#F8AFA8", "#FDDDA0", "#74A089"]
        },
        {
          "type": "character",
          "attributes": {},
          "value": ["#E6A0C4", "#C6CDF7", "#D8A499", "#7294D4"]
        },
        {
          "type": "character",
          "attributes": {},
          "value": ["#85D4E3", "#F4B5BD", "#9C964A", "#CDC08C", "#FAD77B"]
        },
        {
          "type": "character",
          "attributes": {},
          "value": ["#446455", "#FDD262", "#D3DDDC", "#C7B19C"]
        },
        {
          "type": "character",
          "attributes": {},
          "value": ["#3B9AB2", "#78B7C5", "#EBCC2A", "#E1AF00", "#F21A00"]
        },
        {
          "type": "character",
          "attributes": {},
          "value": ["#DD8D29", "#E2D200", "#46ACC8", "#E58601", "#B40F20"]
        },
        {
          "type": "character",
          "attributes": {},
          "value": ["#FF0000", "#00A08A", "#F2AD00", "#F98400", "#5BBCD6"]
        },
        {
          "type": "character",
          "attributes": {},
          "value": ["#E1BD6D", "#EABE94", "#0B775E", "#35274A", "#F2300F"]
        },
        {
          "type": "character",
          "attributes": {},
          "value": ["#A42820", "#5F5647", "#9B110E", "#3F5151", "#4E2A1E", "#550307", "#0C1707"]
        },
        {
          "type": "character",
          "attributes": {},
          "value": ["#ECCBAE", "#046C9A", "#D69C4E", "#ABDDDE", "#000000"]
        }
      ]
    }

