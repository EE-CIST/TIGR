# gmaps_cities hasn't changed

    {
      "type": "list",
      "attributes": {
        "class": {
          "type": "character",
          "attributes": {},
          "value": ["tbl_df", "tbl", "data.frame"]
        },
        "row.names": {
          "type": "integer",
          "attributes": {},
          "value": [1, 2, 3, 4, 5]
        },
        "names": {
          "type": "character",
          "attributes": {},
          "value": ["city", "json"]
        }
      },
      "value": [
        {
          "type": "character",
          "attributes": {},
          "value": ["Houston", "Washington", "New York", "Chicago", "Arlington"]
        },
        {
          "type": "list",
          "attributes": {},
          "value": [
            {
              "type": "list",
              "attributes": {
                "names": {
                  "type": "character",
                  "attributes": {},
                  "value": ["results", "status"]
                }
              },
              "value": [
                {
                  "type": "list",
                  "attributes": {},
                  "value": [
                    {
                      "type": "list",
                      "attributes": {
                        "names": {
                          "type": "character",
                          "attributes": {},
                          "value": ["address_components", "formatted_address", "geometry", "place_id", "types"]
                        }
                      },
                      "value": [
                        {
                          "type": "list",
                          "attributes": {},
                          "value": [
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Houston"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Houston"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["locality"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Harris County"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Harris County"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["administrative_area_level_2"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Texas"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["TX"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["administrative_area_level_1"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["United States"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["US"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["country"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "type": "character",
                          "attributes": {},
                          "value": ["Houston, TX, USA"]
                        },
                        {
                          "type": "list",
                          "attributes": {
                            "names": {
                              "type": "character",
                              "attributes": {},
                              "value": ["bounds", "location", "location_type", "viewport"]
                            }
                          },
                          "value": [
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["northeast", "southwest"]
                                }
                              },
                              "value": [
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [30.1107319]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-95.014496]
                                    }
                                  ]
                                },
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [29.523624]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-95.7880869]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["lat", "lng"]
                                }
                              },
                              "value": [
                                {
                                  "type": "double",
                                  "attributes": {},
                                  "value": [29.7604267]
                                },
                                {
                                  "type": "double",
                                  "attributes": {},
                                  "value": [-95.3698028]
                                }
                              ]
                            },
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["APPROXIMATE"]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["northeast", "southwest"]
                                }
                              },
                              "value": [
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [30.1107319]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-95.014496]
                                    }
                                  ]
                                },
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [29.523624]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-95.7880869]
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "type": "character",
                          "attributes": {},
                          "value": ["ChIJAYWNSLS4QIYROwVl894CDco"]
                        },
                        {
                          "type": "list",
                          "attributes": {},
                          "value": [
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["locality"]
                            },
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["political"]
                            }
                          ]
                        }
                      ]
                    }
                  ]
                },
                {
                  "type": "character",
                  "attributes": {},
                  "value": ["OK"]
                }
              ]
            },
            {
              "type": "list",
              "attributes": {
                "names": {
                  "type": "character",
                  "attributes": {},
                  "value": ["results", "status"]
                }
              },
              "value": [
                {
                  "type": "list",
                  "attributes": {},
                  "value": [
                    {
                      "type": "list",
                      "attributes": {
                        "names": {
                          "type": "character",
                          "attributes": {},
                          "value": ["address_components", "formatted_address", "geometry", "place_id", "types"]
                        }
                      },
                      "value": [
                        {
                          "type": "list",
                          "attributes": {},
                          "value": [
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Washington"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["WA"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["administrative_area_level_1"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["United States"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["US"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["country"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "type": "character",
                          "attributes": {},
                          "value": ["Washington, USA"]
                        },
                        {
                          "type": "list",
                          "attributes": {
                            "names": {
                              "type": "character",
                              "attributes": {},
                              "value": ["bounds", "location", "location_type", "viewport"]
                            }
                          },
                          "value": [
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["northeast", "southwest"]
                                }
                              },
                              "value": [
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [49.0024442]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-116.91558]
                                    }
                                  ]
                                },
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [45.543541]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-124.8489739]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["lat", "lng"]
                                }
                              },
                              "value": [
                                {
                                  "type": "double",
                                  "attributes": {},
                                  "value": [47.7510741]
                                },
                                {
                                  "type": "double",
                                  "attributes": {},
                                  "value": [-120.7401386]
                                }
                              ]
                            },
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["APPROXIMATE"]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["northeast", "southwest"]
                                }
                              },
                              "value": [
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [49.0024945]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-116.91558]
                                    }
                                  ]
                                },
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [45.543541]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-124.8489739]
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "type": "character",
                          "attributes": {},
                          "value": ["ChIJ-bDD5__lhVQRuvNfbGh4QpQ"]
                        },
                        {
                          "type": "list",
                          "attributes": {},
                          "value": [
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["administrative_area_level_1"]
                            },
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["political"]
                            }
                          ]
                        }
                      ]
                    },
                    {
                      "type": "list",
                      "attributes": {
                        "names": {
                          "type": "character",
                          "attributes": {},
                          "value": ["address_components", "formatted_address", "geometry", "place_id", "types"]
                        }
                      },
                      "value": [
                        {
                          "type": "list",
                          "attributes": {},
                          "value": [
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Washington"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Washington"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["locality"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["District of Columbia"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["District of Columbia"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["administrative_area_level_2"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["District of Columbia"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["DC"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["administrative_area_level_1"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["United States"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["US"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["country"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "type": "character",
                          "attributes": {},
                          "value": ["Washington, DC, USA"]
                        },
                        {
                          "type": "list",
                          "attributes": {
                            "names": {
                              "type": "character",
                              "attributes": {},
                              "value": ["bounds", "location", "location_type", "viewport"]
                            }
                          },
                          "value": [
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["northeast", "southwest"]
                                }
                              },
                              "value": [
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [38.9958641]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-76.909393]
                                    }
                                  ]
                                },
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [38.7916449]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-77.119759]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["lat", "lng"]
                                }
                              },
                              "value": [
                                {
                                  "type": "double",
                                  "attributes": {},
                                  "value": [38.9071923]
                                },
                                {
                                  "type": "double",
                                  "attributes": {},
                                  "value": [-77.0368707]
                                }
                              ]
                            },
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["APPROXIMATE"]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["northeast", "southwest"]
                                }
                              },
                              "value": [
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [38.9958641]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-76.909393]
                                    }
                                  ]
                                },
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [38.7916449]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-77.119759]
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "type": "character",
                          "attributes": {},
                          "value": ["ChIJW-T2Wt7Gt4kRKl2I1CJFUsI"]
                        },
                        {
                          "type": "list",
                          "attributes": {},
                          "value": [
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["locality"]
                            },
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["political"]
                            }
                          ]
                        }
                      ]
                    }
                  ]
                },
                {
                  "type": "character",
                  "attributes": {},
                  "value": ["OK"]
                }
              ]
            },
            {
              "type": "list",
              "attributes": {
                "names": {
                  "type": "character",
                  "attributes": {},
                  "value": ["results", "status"]
                }
              },
              "value": [
                {
                  "type": "list",
                  "attributes": {},
                  "value": [
                    {
                      "type": "list",
                      "attributes": {
                        "names": {
                          "type": "character",
                          "attributes": {},
                          "value": ["address_components", "formatted_address", "geometry", "place_id", "types"]
                        }
                      },
                      "value": [
                        {
                          "type": "list",
                          "attributes": {},
                          "value": [
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["New York"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["New York"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["locality"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["New York"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["NY"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["administrative_area_level_1"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["United States"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["US"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["country"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "type": "character",
                          "attributes": {},
                          "value": ["New York, NY, USA"]
                        },
                        {
                          "type": "list",
                          "attributes": {
                            "names": {
                              "type": "character",
                              "attributes": {},
                              "value": ["bounds", "location", "location_type", "viewport"]
                            }
                          },
                          "value": [
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["northeast", "southwest"]
                                }
                              },
                              "value": [
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [40.9175771]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-73.7002721]
                                    }
                                  ]
                                },
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [40.4773991]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-74.2590899]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["lat", "lng"]
                                }
                              },
                              "value": [
                                {
                                  "type": "double",
                                  "attributes": {},
                                  "value": [40.7127753]
                                },
                                {
                                  "type": "double",
                                  "attributes": {},
                                  "value": [-74.0059728]
                                }
                              ]
                            },
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["APPROXIMATE"]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["northeast", "southwest"]
                                }
                              },
                              "value": [
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [40.9175771]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-73.7002721]
                                    }
                                  ]
                                },
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [40.4773991]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-74.2590899]
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "type": "character",
                          "attributes": {},
                          "value": ["ChIJOwg_06VPwokRYv534QaPC8g"]
                        },
                        {
                          "type": "list",
                          "attributes": {},
                          "value": [
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["locality"]
                            },
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["political"]
                            }
                          ]
                        }
                      ]
                    }
                  ]
                },
                {
                  "type": "character",
                  "attributes": {},
                  "value": ["OK"]
                }
              ]
            },
            {
              "type": "list",
              "attributes": {
                "names": {
                  "type": "character",
                  "attributes": {},
                  "value": ["results", "status"]
                }
              },
              "value": [
                {
                  "type": "list",
                  "attributes": {},
                  "value": [
                    {
                      "type": "list",
                      "attributes": {
                        "names": {
                          "type": "character",
                          "attributes": {},
                          "value": ["address_components", "formatted_address", "geometry", "place_id", "types"]
                        }
                      },
                      "value": [
                        {
                          "type": "list",
                          "attributes": {},
                          "value": [
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Chicago"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Chicago"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["locality"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Cook County"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Cook County"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["administrative_area_level_2"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Illinois"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["IL"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["administrative_area_level_1"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["United States"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["US"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["country"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "type": "character",
                          "attributes": {},
                          "value": ["Chicago, IL, USA"]
                        },
                        {
                          "type": "list",
                          "attributes": {
                            "names": {
                              "type": "character",
                              "attributes": {},
                              "value": ["bounds", "location", "location_type", "viewport"]
                            }
                          },
                          "value": [
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["northeast", "southwest"]
                                }
                              },
                              "value": [
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [42.023131]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-87.523661]
                                    }
                                  ]
                                },
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [41.6443349]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-87.9402669]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["lat", "lng"]
                                }
                              },
                              "value": [
                                {
                                  "type": "double",
                                  "attributes": {},
                                  "value": [41.8781136]
                                },
                                {
                                  "type": "double",
                                  "attributes": {},
                                  "value": [-87.6297982]
                                }
                              ]
                            },
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["APPROXIMATE"]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["northeast", "southwest"]
                                }
                              },
                              "value": [
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [42.023131]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-87.523661]
                                    }
                                  ]
                                },
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [41.6443349]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-87.9402669]
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "type": "character",
                          "attributes": {},
                          "value": ["ChIJ7cv00DwsDogRAMDACa2m4K8"]
                        },
                        {
                          "type": "list",
                          "attributes": {},
                          "value": [
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["locality"]
                            },
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["political"]
                            }
                          ]
                        }
                      ]
                    }
                  ]
                },
                {
                  "type": "character",
                  "attributes": {},
                  "value": ["OK"]
                }
              ]
            },
            {
              "type": "list",
              "attributes": {
                "names": {
                  "type": "character",
                  "attributes": {},
                  "value": ["results", "status"]
                }
              },
              "value": [
                {
                  "type": "list",
                  "attributes": {},
                  "value": [
                    {
                      "type": "list",
                      "attributes": {
                        "names": {
                          "type": "character",
                          "attributes": {},
                          "value": ["address_components", "formatted_address", "geometry", "place_id", "types"]
                        }
                      },
                      "value": [
                        {
                          "type": "list",
                          "attributes": {},
                          "value": [
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Arlington"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Arlington"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["locality"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Tarrant County"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Tarrant County"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["administrative_area_level_2"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Texas"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["TX"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["administrative_area_level_1"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["United States"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["US"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["country"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "type": "character",
                          "attributes": {},
                          "value": ["Arlington, TX, USA"]
                        },
                        {
                          "type": "list",
                          "attributes": {
                            "names": {
                              "type": "character",
                              "attributes": {},
                              "value": ["bounds", "location", "location_type", "viewport"]
                            }
                          },
                          "value": [
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["northeast", "southwest"]
                                }
                              },
                              "value": [
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [32.8171209]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-97.037008]
                                    }
                                  ]
                                },
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [32.5865651]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-97.2338181]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["lat", "lng"]
                                }
                              },
                              "value": [
                                {
                                  "type": "double",
                                  "attributes": {},
                                  "value": [32.735687]
                                },
                                {
                                  "type": "double",
                                  "attributes": {},
                                  "value": [-97.1080656]
                                }
                              ]
                            },
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["APPROXIMATE"]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["northeast", "southwest"]
                                }
                              },
                              "value": [
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [32.8171209]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-97.037008]
                                    }
                                  ]
                                },
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [32.5865651]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-97.2338181]
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "type": "character",
                          "attributes": {},
                          "value": ["ChIJ05gI5NJiToYRUVOgH6z2Xgs"]
                        },
                        {
                          "type": "list",
                          "attributes": {},
                          "value": [
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["locality"]
                            },
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["political"]
                            }
                          ]
                        }
                      ]
                    },
                    {
                      "type": "list",
                      "attributes": {
                        "names": {
                          "type": "character",
                          "attributes": {},
                          "value": ["address_components", "formatted_address", "geometry", "place_id", "types"]
                        }
                      },
                      "value": [
                        {
                          "type": "list",
                          "attributes": {},
                          "value": [
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Arlington"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Arlington"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["locality"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Arlington County"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Arlington County"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["administrative_area_level_2"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["Virginia"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["VA"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["administrative_area_level_1"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["long_name", "short_name", "types"]
                                }
                              },
                              "value": [
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["United States"]
                                },
                                {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["US"]
                                },
                                {
                                  "type": "list",
                                  "attributes": {},
                                  "value": [
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["country"]
                                    },
                                    {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["political"]
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "type": "character",
                          "attributes": {},
                          "value": ["Arlington, VA, USA"]
                        },
                        {
                          "type": "list",
                          "attributes": {
                            "names": {
                              "type": "character",
                              "attributes": {},
                              "value": ["bounds", "location", "location_type", "viewport"]
                            }
                          },
                          "value": [
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["northeast", "southwest"]
                                }
                              },
                              "value": [
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [38.934343]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-77.032143]
                                    }
                                  ]
                                },
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [38.82729]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-77.1721691]
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["lat", "lng"]
                                }
                              },
                              "value": [
                                {
                                  "type": "double",
                                  "attributes": {},
                                  "value": [38.8799697]
                                },
                                {
                                  "type": "double",
                                  "attributes": {},
                                  "value": [-77.1067698]
                                }
                              ]
                            },
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["APPROXIMATE"]
                            },
                            {
                              "type": "list",
                              "attributes": {
                                "names": {
                                  "type": "character",
                                  "attributes": {},
                                  "value": ["northeast", "southwest"]
                                }
                              },
                              "value": [
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [38.934343]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-77.032143]
                                    }
                                  ]
                                },
                                {
                                  "type": "list",
                                  "attributes": {
                                    "names": {
                                      "type": "character",
                                      "attributes": {},
                                      "value": ["lat", "lng"]
                                    }
                                  },
                                  "value": [
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [38.82729]
                                    },
                                    {
                                      "type": "double",
                                      "attributes": {},
                                      "value": [-77.1721691]
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        },
                        {
                          "type": "character",
                          "attributes": {},
                          "value": ["ChIJD6ene522t4kRk7D2Rchvz_g"]
                        },
                        {
                          "type": "list",
                          "attributes": {},
                          "value": [
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["locality"]
                            },
                            {
                              "type": "character",
                              "attributes": {},
                              "value": ["political"]
                            }
                          ]
                        }
                      ]
                    }
                  ]
                },
                {
                  "type": "character",
                  "attributes": {},
                  "value": ["OK"]
                }
              ]
            }
          ]
        }
      ]
    }

