This directory contains schema fragments for trees and networks of
various types.