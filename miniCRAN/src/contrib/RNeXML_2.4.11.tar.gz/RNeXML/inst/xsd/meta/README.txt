This directory contains schema fragments for metadata such as annotations
and groupings of objects in sets.