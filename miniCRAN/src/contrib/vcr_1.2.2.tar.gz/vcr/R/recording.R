#' vcr recording options
#'
#' @includeRmd man/rmdhunks/record-modes.Rmd
#'
#' @name recording
NULL
