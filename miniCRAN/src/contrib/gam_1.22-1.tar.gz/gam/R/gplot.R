#' @export
"gplot" <-
function(x, ...)
UseMethod("gplot")
