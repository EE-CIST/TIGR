library(testthat)
library(insight)
test_check("insight")
