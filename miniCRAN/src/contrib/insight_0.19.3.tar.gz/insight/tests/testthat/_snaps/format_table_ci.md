# format_table with multiple si-levels

    Code
      x
    Output
      Highest Density Interval
      
      80% HDI       |       90% HDI
      -----------------------------
      [-1.28, 1.28] | [-1.65, 1.64]

