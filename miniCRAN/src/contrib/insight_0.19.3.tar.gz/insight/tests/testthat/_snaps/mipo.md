# param

    Code
      out1
    Output
          Parameter Estimate Response
      1 (Intercept) -54.2937        6
      2        disp   0.2231        6
      3          hp   0.2030        6
      4 (Intercept) -92.8615        8
      5        disp   0.2578        8
      6          hp   0.4259        8

---

    Code
      out2
    Output
          Parameter Statistic Response
      1 (Intercept)   -1.1577        6
      2        disp    0.5763        6
      3          hp    0.3571        6
      4 (Intercept)   -1.3732        8
      5        disp    0.6402        8
      6          hp    0.6742        8

