# reorder columns BF

    Code
      format_table(out)
    Output
          Parameter   Component Median         95% CI   pd % in ROPE       BF  Rhat
      1 b_Intercept conditional  32.22 [27.22, 35.76] 100%        0% 1.97e+06 1.004
      2        b_wt conditional  -3.76 [-4.97, -2.21] 100%        0%   330.18 1.001
      3       sigma       sigma   3.46 [ 2.65,  4.70] 100%        0% 7.29e+03 0.992
           ESS
      1  88.00
      2  92.00
      3 168.00

