1.1.5
==========
* update URLs for new repository.

ncdfgeom 1.1.1
==========
* Updates to read and write timeseries DSG. Should be backwards compatible.

ncdfgeom 1.1.0
==========
* Added class `ncdfgeom` to response from `read_timeseries_dsg` for compatibility with `stars`.
* Added citation information.
* Bug fix in handling of multilinestrings.