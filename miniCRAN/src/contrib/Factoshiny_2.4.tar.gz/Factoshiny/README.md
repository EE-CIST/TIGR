# Factoshiny

You can see the Website dedicated to Factoshiny (<a href="http://factominer.free.fr/graphs/factoshiny.html">link for English version</a>, and for <a href="http://factominer.free.fr/graphs/factoshiny-fr.html">the French version</a>)


How do you install the latest version of Factoshiny available on GitHub?

```{r}
if (!require("devtools")) install.packages("devtools")
library(devtools)
install_github("husson/Factoshiny")
```