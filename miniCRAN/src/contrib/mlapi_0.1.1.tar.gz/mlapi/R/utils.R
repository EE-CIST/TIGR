#' @importFrom Matrix Matrix
#' @importFrom R6 R6Class
raise_placeholder_error = function()
  stop("Placeholder for method. Subclasses should implement this method!")
