library(testthat)
library(themis)

test_check("themis")
