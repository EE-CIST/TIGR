#include <math.h>
#include <stdlib.h>

#include <R.h>
