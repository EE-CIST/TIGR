library(testthat)
library(phylolm)

test_check("phylolm")
