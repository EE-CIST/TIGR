library(RJSONIO)

ins = c("[1, 2, 3]",
        '[1, "2", 3]',
        '[true, 1, 3]',
        '[true, false, 3, "xyz"]')



