# phosphoricons 0.2.0

* Updated to Phosphoricons v2.0.2, adding 201 new icons (see https://github.com/phosphor-icons/core/releases/tag/v2.0.0).



# phosphoricons 0.1.2

* Updated to Phosphoricons v1.4.1



# phosphoricons 0.1.1

* Initial release: use icons by [Phosphoricons](https://phosphoricons.com/) in web pages (shiny, rmarkdown) created with R.
