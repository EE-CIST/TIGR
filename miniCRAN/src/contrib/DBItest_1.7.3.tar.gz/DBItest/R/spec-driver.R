#' @format NULL
spec_driver <- c(
  spec_driver_constructor,
  spec_driver_data_type,
  spec_driver_get_info,
  spec_driver_connect,
  #
  NULL
)
