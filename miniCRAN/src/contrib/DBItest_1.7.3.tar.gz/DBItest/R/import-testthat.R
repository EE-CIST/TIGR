#' @import testthat
#' @importFrom rlang quo enquo enquos expr enexpr eval_tidy list2 has_length :=
#' @importFrom rlang abort is_interactive as_function local_options seq2 set_names
#' @importFrom rlang %||% global_env is_logical
NULL

#' @importFrom methods findMethod getClasses getClass extends
#' @importFrom stats setNames
#' @importFrom utils head
NULL
