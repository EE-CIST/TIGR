#' @format NULL
spec_transaction <- c(
  spec_transaction_begin_commit_rollback,
  spec_transaction_with_transaction,
  #
  NULL
)
