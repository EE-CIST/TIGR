#' @name nc_grids 
#' @export 
nc_grids.tidync <- function(x, ...) {
  x[["grids"]]
}