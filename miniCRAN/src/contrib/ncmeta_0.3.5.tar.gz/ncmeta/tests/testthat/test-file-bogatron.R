# library(testthat)
# 
# context("file-bogatron")
# test_that({
#   skip_if_not(we_are_raady())
#  # sstd1 <- raadtools::sstfiles()$fullname[1]
#  # sstm1 <-
# #    raadtools::sstfiles(time.resolution = "monthly")$fullname[1]
# #  rom1 <- raadtools::cpolarfiles()$fullname[1]
# })
