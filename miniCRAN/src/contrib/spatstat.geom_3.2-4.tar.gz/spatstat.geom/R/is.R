##  is.R
## original for spatstat.geom

is.lpp <- function(x) { inherits(x, "lpp") }

is.linnet <- function(x) { inherits(x, "linnet") }

is.fv <- function(x) { inherits(x, "fv") }

is.linim <- function(x) { inherits(x, "linim") }

