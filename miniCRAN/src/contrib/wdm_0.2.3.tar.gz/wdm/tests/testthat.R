library(testthat)
library(wdm)

test_check("wdm")
