#!/usr/bin/env Rscript

library(testthat)
library(tibble)
library(dplyr)
library(tidygeocoder)

test_check("tidygeocoder")
