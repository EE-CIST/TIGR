library(testthat)
library(hipread)

test_check("hipread")
