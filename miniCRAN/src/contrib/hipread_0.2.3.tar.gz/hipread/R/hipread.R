#' @keywords internal
#' @importFrom R6 R6Class
"_PACKAGE"
