library(testthat)
library(flextable)
library(officer)

test_check("flextable")
