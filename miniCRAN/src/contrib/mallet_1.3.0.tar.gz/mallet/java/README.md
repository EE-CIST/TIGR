Make CRAN quiet about:  
    Package has FOSS license, installs .class/.jar but has no 'java' directory.
See https://github.com/mimno/Mallet for details on code.
