getindexcat <- function(data) {
   colnames(dichotom(data))
   }
