jomo2mitml.list <- function(x){
# convert jomo imputations to mitml.list

  long2mitml.list(x, split = "Imputation", exclude = 0)

}

