.onAttach <- function(libname, pkgname){

  packageStartupMessage("*** This is beta software. Please report any bugs!\n*** See the NEWS file for recent changes.")

}

