const double *cond_sim(double *est, int n_sim, METHOD m, int *is_pt, int orc);
void correct_orv(double *est, int n_vars, int orc);
void print_orvc(void);
