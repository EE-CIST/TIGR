library(testthat)
library(cleanrmd)

test_check("cleanrmd")
