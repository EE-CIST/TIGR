library(testthat)
library(colourvalues)

test_check("colourvalues")
