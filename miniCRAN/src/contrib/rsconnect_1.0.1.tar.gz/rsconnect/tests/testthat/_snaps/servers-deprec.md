# addConnectServer is deprecated

    Code
      addConnectServer("https://colorado.posit.co/rsc", quiet = TRUE)
    Condition
      Warning:
      `addConnectServer()` was deprecated in rsconnect 1.0.0.
      i Please use `addServer()` instead.

