whichFacto <-
function(res) {class(res)[1]}
