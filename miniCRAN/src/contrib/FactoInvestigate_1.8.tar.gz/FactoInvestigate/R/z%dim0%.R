`%dim0%` <-
function(e1, e2) if(length(e1) == 0) {e2} else {e1}
