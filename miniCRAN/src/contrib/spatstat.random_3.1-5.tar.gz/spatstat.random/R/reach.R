#
#   reach.R
#
#  $Revision: 1.10 $   $Date: 2022/11/03 11:08:33 $
#

reach <- function(x, ...) {
  UseMethod("reach")
}


