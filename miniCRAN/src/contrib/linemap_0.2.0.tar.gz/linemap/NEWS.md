# linemap 0.2.0

## Minor changes
- Remove some RData in favor of geopackage (This can lead to breaking changes using examples)
- fix NOTES by importing geopackage instead of RData
- Add test, code coverage and GH action
- Fix links

