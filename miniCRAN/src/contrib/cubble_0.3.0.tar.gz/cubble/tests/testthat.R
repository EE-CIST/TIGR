library(testthat)
library(cubble)

#test_check("cubble")
