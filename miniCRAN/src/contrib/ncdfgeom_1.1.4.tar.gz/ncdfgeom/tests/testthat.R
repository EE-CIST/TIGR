library(testthat)
test_check("ncdfgeom")
