library(testthat)
library(decor)

test_check("decor")
