library(testthat)
library(smd)

test_check("smd")
