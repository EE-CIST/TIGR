function(response) {
  within_body_text(response, function(txt) '{"fake":true}')
}
