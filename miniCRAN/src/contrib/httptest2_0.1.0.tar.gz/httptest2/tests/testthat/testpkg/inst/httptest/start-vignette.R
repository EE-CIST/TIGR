options(testpkg.start.vignette = TRUE)
