options(testpkg.start.vignette = FALSE)
