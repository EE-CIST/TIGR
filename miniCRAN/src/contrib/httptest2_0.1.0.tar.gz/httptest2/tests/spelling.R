spelling::spell_check_test(vignettes = TRUE, error = nzchar(Sys.getenv("GITHUB_WORKSPACE")))
