"ellipse" <-function (x, ...) 
  UseMethod("ellipse")
