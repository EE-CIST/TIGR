library(testthat)
library(rr2)

test_check("rr2")