
See https://github.com/Redocly/redoc#readme for Redoc.

Redoc authors:

* Roman Hotsiy <gotsijroman@gmail.com>
* Cesar <cesarlevel@gmail.com>
* Dimitar Nanov <dimitar.nanov@ecollect.net>
* Ivan Goncharov <ivan.goncharov.ua@gmail.com>
* Anya Stasiuk <stasiukanya@gmail.com>
* Bohdan Khorolets <bogdan@khorolets.com>
* Brendan Abbott <brendan@bloodbone.ws>
* Ben Firshman <ben@firshman.co.uk>
* brushmate <brushmate@gmail.com>
* Adam Altman <adam@ilabsinc.com>
* Jérémy Derussé <jeremy@derusse.com>
* Matthias Mohr <webmaster@mamo-net.de>
* Mike Stead <mike.stead@massive.co>
* kedashoe <kwallace@gmail.com>
* leoliu <leoliu@yunify.com>
* amanganiello <a.manganiello@emminformatica.it>
* Patrick Elam <40776618+patrickelam@users.noreply.github.com>
* Mohamed Zenadi <zeapo@users.noreply.github.com>
* Sergey Dubovyk <knidarkness@gmail.com>
* Zakary Kamal Ismail <zakary.kamal.fs@outlook.com>
* Jon Nicholson <drjonnicholson@users.noreply.github.com>
* Alex <alexgmin@gmail.com>
* TATSUNO Yasuhiro <tatsuno_yasuhiro@kurusugawa.jp>
* Oleksiy Kachynskyy <okachynskyy@users.noreply.github.com>
* Mike Ralphson <mike.ralphson@gmail.com>
* Phil Sturgeon <philsturgeon@users.noreply.github.com>
* Dimitar Nanov <mitko.n@gmail.com>
* Faheem Abrar <faheem.abrar@outlook.com>
* Fredrik Lengstrand <10126466+fredriklengstrand@users.noreply.github.com>
* Gaurav Jain <gaurav@gauravjain.org>
* George Wilson <georgejameswilson@googlemail.com>
* GreenHedgehog <IrishGreenHedgehog@gmail.com>
* Homa Wong <homawong@gmail.com>
* Ingo Claro <miclaro@gmail.com>
* Jacob Baskin <jacob.baskin@gmail.com>
* Jean-Daniel <Jean-Daniel@users.noreply.github.com>
* Joe Honzawa <goflb.jh@gmail.com>
* Josh Price <josh@alembic.com.au>
* Julian <2564520+julmuell@users.noreply.github.com>
* Julian Kühnel <me@juliankuehnel.com>
* Julien Feltesse <jfeltesse@mdsol.com>
* Khoa Tran <khoatran@temando.com>
* Kris Kalavantavanich <krismath.K@gmail.com>
* Kryštof Korb <krystof@korb.cz>
* LeFnord <pscholz.le@gmail.com>
* Leonard Ehrenfried <leonard.ehrenfried@gmail.com>
* Lev Pachmanov <31389480+levpachmanov@users.noreply.github.com>
* Luciano Jr <luciano@lucianojr.com.br>
* Luigi Pinca <luigipinca@gmail.com>
* Making GitHub Delicious <iron@waffle.io>
* Marius Rumpf <MariusRumpf@users.noreply.github.com>
* Mason Malone <mason.malone@gmail.com>
* Mathias Schreck <schreck.mathias@googlemail.com>
* Melvyn Sopacua <40824897+mes3yd@users.noreply.github.com>
* Melvyn Sopacua <mes@3yourmind.com>
* Michael Huynh <43751307+miqh@users.noreply.github.com>
* Morgan Terry <localstatic@users.noreply.github.com>
* Nan Yan <625518543@qq.com>
* Nick Oliver <github@pixnbits.org>
* Oleg Vaskevich <oleg@osv.im>
* Patrick Niklaus <github@execfoo.de>
* Patrick Rodacker <lordrhodos@users.noreply.github.com>
* Pete Nykänen <pete.a.nykanen@gmail.com>
* Peter Golm <golm.peter@gmail.com>
* Peter Wessels <pjotrwes@hotmail.com>
* Petr Flaks <flaks-petr@protonmail.com>
* Primož Pincolič <primozweb@gmail.com>
* Quinn Blenkinsop <quinn@qw-in.com>
* Robert DeRose <RobertDeRose@users.noreply.github.com>
* Sander van de Graaf <sander@vandegraaf.nl>
* Sebastián Ramírez <tiangolo@gmail.com>
* Sergio Regueira <sergio@sergioregueira.com>
* SeungWoon Maz Lee <mazicky@gmail.com>
* Sheila Kelly <36901025+viralanomaly@users.noreply.github.com>
* Siarhei Bautrukevich <bautrukevich@users.noreply.github.com>
* Skyler Lewis <sblnog@gmail.com>
* SoftBrix <andreas@softbrix.se>
* Sérgio Ramos <mail@sergioramos.me>
* Tim Hordern <tim.hordern@gmail.com>
* Vincent Giersch <vincent@giersch.fr>
* Vladimir L <vladimir.lioubitelev@gmail.com>
* William Boman <william+github@redwill.se>
* Zach Pomerantz <zmp@umich.edu>
* bwjohnson-ss <41123899+bwjohnson-ss@users.noreply.github.com>
* davchen51 <46250804+davchen51@users.noreply.github.com>
* duxiaofeng <duxiaofeng-github@users.noreply.github.com>
* fritz-c <fritz-c@users.noreply.github.com>
* jsmartfo <james.jerome.smartfoster@aexp.com>
* kmbenitez <kathleen.benitez@gmail.com>
* lrobledo <lrobledo@cmsonline.com>
* lscholten <info@luukscholten.com>
* mknoszlig <maximilian.karasz@googlemail.com>
* neumond <knifeslaughter@gmail.com>
* pengfluf <pengfluf@tutanota.com>
* russellrobinson <russellrobinson@users.noreply.github.com>
* tomjankes <tomjankes@users.noreply.github.com>
* torbenw <torbenw@users.noreply.github.com>
* travis@localhost <travis@localhost>
* unarist <m.unarist@gmail.com>
* zhzxang <xuzhang3371@163.com>
* Adam Altman <adam@redoc.ly>
* Adam DuVander <adamd@users.noreply.github.com>
* Adrien Gallou <adriengallou@gmail.com>
* Aleksandr Karo <alex@karo-dev.ru>
* Alex Scammon <stackedsax@users.noreply.github.com>
* Anastasiya Mashoshyna <a.mashoshyna@gmail.com>
* Andrew Berry <deviantintegral@gmail.com>
* Andrew Zhukevych <34597767+Hollister009@users.noreply.github.com>
* Andrii Tykhan <andriytixan@gmail.com>
* Antherkiv <antherkiv@gmail.com>
* Anthony Porthouse <anthony@porthou.se>
* Anto <antograssiot@free.fr>
* Anton Komarev <1849174+antonkomarev@users.noreply.github.com>
* Benny Neugebauer <bn@bennyn.de>
* Blake Erickson <o.blakeerickson@gmail.com>
* Brendan Abbott <brendan.abbott@temando.com>
* Cesar Landeros Delgado <chichozell@gmail.com>
* Cesar Level <cesarlevel@gmail.com>
* Chris Faulkner <thefaulkner@gmail.com>
* Cédric Bertolini <41571181+wizacedric@users.noreply.github.com>
* Cédric Fabianski <cfabianski@me.com>
* Daniel Chao <daniel.h.chao@gmail.com>
* Dave Oram <david.oram99@gmail.com>
* David Beacham <dbeacham@dbeacham.co.uk>
* David Cumps <CumpsD@users.noreply.github.com>
* David J. Felix <felix.davidj@gmail.com>
* David Revay <MrBlenny@users.noreply.github.com>
* DeBr0glie <afrimuchkov@yandex.ru>

The authors were extracted from the git history:
```sh
git clone https://github.com/Redocly/redoc.git
cd redoc
git shortlog --summary --numbered --email --all | cut -f2 | sed 's/^/* /'
```
