library(testthat)
library(webfakes)

test_check("webfakes")
