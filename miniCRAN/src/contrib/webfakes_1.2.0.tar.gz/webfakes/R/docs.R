
#' @title webfakes glossary
#' @name glossary
#' @section Webfakes glossary:
#'
#' ```{r child = "vignettes/glossary.Rmd"}
#' ```
NULL
