library("testthat")

library("TSP")
test_check("TSP")


