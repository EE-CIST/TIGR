#ifndef NV_PR_INCLUDED
#define NV_PR_INCLUDED

void write_nv_pr_xlsx(pDevDesc dev, const char *label);
void write_nv_pr_pptx(pDevDesc dev, const char *label);

#endif
