# pryr

<!-- badges: start -->
[![Lifecycle: superseded](https://img.shields.io/badge/lifecycle-superseded-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#superseded)
[![R-CMD-check](https://github.com/hadley/pryr/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/hadley/pryr/actions/workflows/R-CMD-check.yaml)
<!-- badges: end -->

pryr is superseded. Please use:

* [rlang](https://rlang.r-lib.org/) for low-level R programming.
* [lobstr](https://lobstr.r-lib.org/) for object sizes & comparison.
* [sloop](https://sloop.r-lib.org/) for OOP tools.
