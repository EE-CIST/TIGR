ray_has_tex_envir = new.env(parent = emptyenv())
ray_has_norm_envir = new.env(parent = emptyenv())
