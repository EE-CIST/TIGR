#' The available GIBS layers with attributes
"gibs_layers"
