library(testthat)
library(htmltools)
library(leaflet)
library(leaflet.extras2)

test_check("leaflet.extras2")
