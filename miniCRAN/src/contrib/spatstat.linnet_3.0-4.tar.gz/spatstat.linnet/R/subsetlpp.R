#'
#' spatstat.linnet/R/subsetlpp.R
#'
#' $Revision: 1.1 $ $Date: 2020/06/16 03:19:14 $
#'

subset.lpp <- subset.ppx
