#' @noRd
crs_wkt <- function(x, ...) {
  .Defunct("crs_wkt2")
}
