# crsmeta 0.3.0

* Fixed tests and in-built data sets in terms of the old-style
 and new-style support of crs in sf. 
 
* New function `crs_input()` for new type sf. 

* Early features. 
