library(testthat)
library(crsmeta)
if (FALSE) {  ## only test interactively, not in R CMD check
 test_check("crsmeta")
}
