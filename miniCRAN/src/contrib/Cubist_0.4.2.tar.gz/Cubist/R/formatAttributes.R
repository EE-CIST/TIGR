formatAttributes <-
function(x)
  {
    ## gsub special chars with escapes
    x
  }

