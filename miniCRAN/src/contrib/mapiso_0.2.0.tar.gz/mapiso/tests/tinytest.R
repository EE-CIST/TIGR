if (requireNamespace("tinytest", quietly = TRUE)) {
  library(tinytest)
  test_package("mapiso")
}
