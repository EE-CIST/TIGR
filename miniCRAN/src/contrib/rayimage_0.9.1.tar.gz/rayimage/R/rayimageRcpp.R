#' @useDynLib rayimage, .registration = TRUE
#' @importFrom Rcpp evalCpp
NULL
