library(testthat)
library(questionr)

test_check("questionr")
