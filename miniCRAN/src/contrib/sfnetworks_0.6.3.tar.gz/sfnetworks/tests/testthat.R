library(testthat)
library(sfnetworks)

test_check("sfnetworks")
